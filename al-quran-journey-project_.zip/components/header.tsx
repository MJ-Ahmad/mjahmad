'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Menu, X, Globe } from 'lucide-react'
import { Button } from '@/components/ui/button'

const navigation = [
  { name: 'Projects', href: '/projects', icon: '🚀' },
  { name: 'Documentation', href: '/documentation', icon: '📚' },
  { name: 'Community', href: '/community', icon: '👥' },
  { name: 'Resources', href: '/resources', icon: '🎓' },
  { name: 'Initiatives', href: '/initiatives', icon: '💡' },
]

const languages = [
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'bn', name: 'বাংলা', flag: '🇧🇩' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦' },
]

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState('en')
  const [languageMenuOpen, setLanguageMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-gradient-to-b from-background to-secondary/20 border-b border-primary/20 backdrop-blur-md">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground flex items-center justify-center font-black text-xl shadow-lg group-hover:shadow-xl transition-all">
              ق
            </div>
            <div className="hidden sm:inline">
              <p className="font-bold text-foreground group-hover:text-primary transition-colors text-sm">
                Quraner Fariwala
              </p>
              <p className="text-xs text-foreground/60 font-medium">Excellence • Heritage • Impact</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="px-4 py-2 text-sm font-semibold text-foreground hover:text-primary hover:bg-primary/5 rounded-lg transition-all duration-300 flex items-center gap-2"
              >
                <span>{item.icon}</span>
                {item.name}
              </Link>
            ))}
          </div>

          {/* Desktop CTA */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => setLanguageMenuOpen(!languageMenuOpen)}
                className="p-2 hover:bg-primary/10 rounded-lg transition-colors flex items-center gap-2 font-semibold text-sm text-foreground"
              >
                <Globe className="w-4 h-4" />
                {currentLanguage.toUpperCase()}
              </button>
              {languageMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-background border border-primary/30 rounded-lg shadow-lg z-50">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setCurrentLanguage(lang.code)
                        setLanguageMenuOpen(false)
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-primary/5 transition-colors flex items-center gap-2 first:rounded-t-lg last:rounded-b-lg"
                    >
                      <span>{lang.flag}</span>
                      {lang.name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <Button
              asChild
              className="bg-gradient-to-r from-primary to-primary/90 text-primary-foreground hover:shadow-lg font-semibold"
            >
              <Link href="/donate">Donate / Support</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 hover:bg-secondary rounded-lg transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-foreground" />
            ) : (
              <Menu className="w-6 h-6 text-foreground" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden pb-6 border-t border-border">
            <div className="space-y-2 pt-4">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="block px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-lg transition-colors flex items-center gap-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span>{item.icon}</span>
                  {item.name}
                </Link>
              ))}
              
              {/* Mobile Language Selector */}
              <div className="px-4 py-3 border-t border-border/50 mt-4">
                <p className="text-xs font-semibold text-foreground/60 mb-2">Language</p>
                <div className="grid grid-cols-3 gap-2">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => setCurrentLanguage(lang.code)}
                      className={`p-2 rounded-lg text-sm font-semibold transition-all ${
                        currentLanguage === lang.code
                          ? 'bg-primary/20 border border-primary text-primary'
                          : 'bg-secondary hover:bg-secondary/80 text-foreground'
                      }`}
                    >
                      <span className="block mb-1">{lang.flag}</span>
                      {lang.code.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                asChild
                className="w-full bg-gradient-to-r from-primary to-primary/90 text-primary-foreground hover:shadow-lg mt-4 font-semibold"
              >
                <Link href="/donate">Donate / Support</Link>
              </Button>
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}
