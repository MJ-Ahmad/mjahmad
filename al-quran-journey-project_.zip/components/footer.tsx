'use client'

import Link from 'next/link'

const footerSections = [
  {
    title: 'About',
    links: [
      { name: 'About Us', href: '/about' },
      { name: 'Our Vision', href: '/about#vision' },
      { name: 'Contact Info', href: '/about#contact' },
      { name: 'Pitch Deck', href: '/pitch-deck' },
    ],
  },
  {
    title: 'Projects',
    links: [
      { name: 'Gallery', href: '/gallery' },
      { name: 'Production', href: '/production' },
      { name: 'Distribution', href: '/distribution' },
      { name: 'Publications', href: '/publications' },
    ],
  },
  {
    title: 'Community',
    links: [
      { name: 'Donate Now', href: '/donate' },
      { name: 'Sponsorship Tracker', href: '/sponsorship-tracker' },
      { name: 'Social Media Kit', href: '/social-media-kit' },
      { name: 'Contact Us', href: '/contact' },
    ],
  },
  {
    title: 'Legal',
    links: [
      { name: 'Privacy Policy', href: '/privacy' },
      { name: 'Terms of Service', href: '/terms' },
      { name: 'Contact', href: '/contact' },
      { name: 'Accessibility', href: '/accessibility' },
    ],
  },
]

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="relative bg-gradient-to-br from-background via-secondary/50 to-primary/5 border-t border-primary/20">
      {/* Decorative background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 mb-12">
            {footerSections.map((section) => (
              <div key={section.title} className="group">
                <h3 className="font-bold text-lg text-foreground mb-6 group-hover:text-primary transition-colors">
                  {section.title}
                </h3>
                <ul className="space-y-3">
                  {section.links.map((link) => (
                    <li key={link.name}>
                      <Link
                        href={link.href}
                        className="text-foreground/70 hover:text-primary hover:translate-x-1 transition-all duration-300 text-sm font-medium"
                      >
                        {link.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Newsletter Signup */}
          <div className="border-t border-primary/20 pt-12 pb-12">
            <div className="max-w-2xl">
              <h3 className="font-bold text-2xl text-foreground mb-3">Stay Updated</h3>
              <p className="text-foreground/70 text-base mb-6 leading-relaxed">
                Subscribe for exclusive updates about our Ramadhan-2026 campaign, distribution milestones, and impact stories.
              </p>
              <form className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  placeholder="Enter your email address"
                  className="flex-1 px-5 py-3 rounded-lg bg-background border border-primary/30 text-foreground placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm font-medium transition-all"
                />
                <button
                  type="submit"
                  className="px-8 py-3 bg-gradient-to-r from-primary to-accent text-foreground rounded-lg hover:shadow-lg hover:scale-105 transition-all duration-300 font-semibold whitespace-nowrap"
                >
                  Subscribe
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-primary/20 py-10 flex flex-col gap-6 sm:flex-row justify-between items-start sm:items-center">
          <div>
            <div className="font-bold text-foreground mb-2">Quraner Fariwala Ltd</div>
            <p className="text-sm text-foreground/70 mb-1">© {currentYear} All rights reserved.</p>
            <p className="text-xs text-foreground/60 font-mono">UK Registered: Reg. 14066998 | TRAD License: DSCC/03727/2021</p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2 text-foreground/80 hover:text-primary transition-colors">
              <span className="text-base">📧</span>
              <a href="mailto:quranerfariwala@gmail.com" className="font-medium hover:underline">
                quranerfariwala@gmail.com
              </a>
            </div>
            <div className="flex items-center gap-2 text-foreground/80 hover:text-primary transition-colors">
              <span className="text-base">📱</span>
              <a href="tel:+8801788856628" className="font-medium hover:underline">
                +880-1788856628
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
