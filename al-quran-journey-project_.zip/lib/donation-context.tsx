'use client'

import React, { createContext, useContext, useState, useCallback } from 'react'

export interface DonationItem {
  id: string
  name: string
  description: string
  amount: number
  quantity: number
  impact: string
}

interface DonationContextType {
  items: DonationItem[]
  addItem: (item: DonationItem) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  getTotalAmount: () => number
}

const DonationContext = createContext<DonationContextType | undefined>(undefined)

export function DonationProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<DonationItem[]>([])

  const addItem = useCallback((item: DonationItem) => {
    setItems((prevItems) => {
      const existingItem = prevItems.find((i) => i.id === item.id)
      if (existingItem) {
        return prevItems.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + item.quantity } : i
        )
      }
      return [...prevItems, item]
    })
  }, [])

  const removeItem = useCallback((id: string) => {
    setItems((prevItems) => prevItems.filter((i) => i.id !== id))
  }, [])

  const updateQuantity = useCallback((id: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(id)
      return
    }
    setItems((prevItems) =>
      prevItems.map((i) => (i.id === id ? { ...i, quantity } : i))
    )
  }, [removeItem])

  const clearCart = useCallback(() => {
    setItems([])
  }, [])

  const getTotalAmount = useCallback(() => {
    return items.reduce((total, item) => total + item.amount * item.quantity, 0)
  }, [items])

  return (
    <DonationContext.Provider
      value={{ items, addItem, removeItem, updateQuantity, clearCart, getTotalAmount }}
    >
      {children}
    </DonationContext.Provider>
  )
}

export function useDonation() {
  const context = useContext(DonationContext)
  if (!context) {
    throw new Error('useDonation must be used within DonationProvider')
  }
  return context
}
