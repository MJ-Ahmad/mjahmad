"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Book,
  BookOpen,
  Building2,
  FileText,
  Globe2,
  LayoutDashboard,
  Library,
  Printer,
  ScrollText,
  Users,
} from "lucide-react"

export default function Dashboard() {
  return (
    <div className="h-full flex">
      {/* Sidebar */}
      <div className="hidden lg:flex h-screen w-64 flex-col fixed left-0 top-0 border-r bg-background">
        <div className="p-6 border-b">
          <h1 className="text-xl font-semibold flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-emerald-600" />
            AlQuranJourney
          </h1>
          <p className="text-sm text-muted-foreground mt-1">TrustedAlly Project</p>
        </div>
        <ScrollArea className="flex-1 p-4">
          <nav className="space-y-2">
            <a
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-900 transition-all hover:text-emerald-600"
              href="#"
            >
              <LayoutDashboard className="h-4 w-4" />
              Dashboard
            </a>
            <a
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-900 transition-all hover:text-emerald-600"
              href="#"
            >
              <ScrollText className="h-4 w-4" />
              Research
            </a>
            <a
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-900 transition-all hover:text-emerald-600"
              href="#"
            >
              <Printer className="h-4 w-4" />
              Printing
            </a>
            <a
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-900 transition-all hover:text-emerald-600"
              href="#"
            >
              <Globe2 className="h-4 w-4" />
              Distribution
            </a>
            <a
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-900 transition-all hover:text-emerald-600"
              href="#"
            >
              <Building2 className="h-4 w-4" />
              Administration
            </a>
          </nav>
        </ScrollArea>
      </div>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 h-screen overflow-y-auto">
        <div className="p-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Publications</CardTitle>
                <Library className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,284</div>
                <p className="text-xs text-muted-foreground">+12% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Research</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24</div>
                <p className="text-xs text-muted-foreground">8 pending approval</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Distribution Centers</CardTitle>
                <Globe2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">48</div>
                <p className="text-xs text-muted-foreground">Across 15 countries</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Team Members</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">312</div>
                <p className="text-xs text-muted-foreground">In 4 departments</p>
              </CardContent>
            </Card>
          </div>

          <div className="mt-6">
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="research">Research</TabsTrigger>
                <TabsTrigger value="printing">Printing</TabsTrigger>
                <TabsTrigger value="distribution">Distribution</TabsTrigger>
              </TabsList>
              <TabsContent value="overview" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Project Overview</CardTitle>
                    <CardDescription>
                      AlQuranJourney is focused on research, printing, and distribution of the Holy Quran
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                        <div className="space-y-2">
                          <h4 className="text-sm font-medium">Recent Research</h4>
                          <ul className="text-sm space-y-2">
                            <li className="flex items-center gap-2">
                              <Book className="h-4 w-4 text-emerald-600" />
                              Manuscript Analysis Study
                            </li>
                            <li className="flex items-center gap-2">
                              <Book className="h-4 w-4 text-emerald-600" />
                              Historical Context Research
                            </li>
                            <li className="flex items-center gap-2">
                              <Book className="h-4 w-4 text-emerald-600" />
                              Preservation Techniques
                            </li>
                          </ul>
                        </div>
                        <div className="space-y-2">
                          <h4 className="text-sm font-medium">Printing Status</h4>
                          <ul className="text-sm space-y-2">
                            <li className="flex items-center gap-2">
                              <Printer className="h-4 w-4 text-emerald-600" />
                              Current Batch: 5,000 copies
                            </li>
                            <li className="flex items-center gap-2">
                              <Printer className="h-4 w-4 text-emerald-600" />
                              Quality Control: In Progress
                            </li>
                            <li className="flex items-center gap-2">
                              <Printer className="h-4 w-4 text-emerald-600" />
                              Next Batch: Scheduled
                            </li>
                          </ul>
                        </div>
                        <div className="space-y-2">
                          <h4 className="text-sm font-medium">Distribution Updates</h4>
                          <ul className="text-sm space-y-2">
                            <li className="flex items-center gap-2">
                              <Globe2 className="h-4 w-4 text-emerald-600" />
                              New Center: Malaysia
                            </li>
                            <li className="flex items-center gap-2">
                              <Globe2 className="h-4 w-4 text-emerald-600" />
                              Shipment: UAE (In Transit)
                            </li>
                            <li className="flex items-center gap-2">
                              <Globe2 className="h-4 w-4 text-emerald-600" />
                              Feedback: 98% Positive
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="research" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Research Projects</CardTitle>
                    <CardDescription>Current and upcoming research initiatives</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">{/* Research content would go here */}</div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="printing" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Printing Operations</CardTitle>
                    <CardDescription>Current printing status and schedules</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">{/* Printing content would go here */}</div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="distribution" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Distribution Network</CardTitle>
                    <CardDescription>Global distribution centers and activities</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">{/* Distribution content would go here */}</div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}
