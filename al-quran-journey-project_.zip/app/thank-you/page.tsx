import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { CheckCircle, Mail, Heart } from 'lucide-react'

export default function ThankYouPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Success Section */}
      <section className="flex-1 flex items-center justify-center px-4 py-20">
        <div className="max-w-2xl mx-auto text-center">
          <div className="mb-6 flex justify-center">
            <CheckCircle className="w-20 h-20 text-accent animate-pulse" />
          </div>

          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-4">
            Thank You for Your Donation!
          </h1>

          <p className="text-xl text-foreground/70 mb-8">
            Your generosity will make a real difference in spreading the Holy Quran to communities
            worldwide. We are deeply grateful for your support.
          </p>

          {/* Confirmation Card */}
          <div className="bg-accent/10 border border-accent/30 rounded-lg p-8 mb-8">
            <h2 className="text-lg font-semibold text-foreground mb-4">Donation Confirmed</h2>
            <div className="space-y-2 text-left mb-6">
              <div className="flex justify-between pb-2 border-b border-accent/20">
                <span className="text-foreground/70">Confirmation Number:</span>
                <span className="font-mono font-semibold text-foreground">#2025-{Math.random().toString(36).substring(2, 10).toUpperCase()}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-accent/20">
                <span className="text-foreground/70">Date:</span>
                <span className="text-foreground font-medium">{new Date().toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-foreground/70">Status:</span>
                <span className="text-accent font-medium flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  Successfully Processed
                </span>
              </div>
            </div>
          </div>

          {/* What's Next */}
          <div className="bg-secondary/30 border border-border rounded-lg p-8 mb-8 text-left">
            <h3 className="text-lg font-semibold text-foreground mb-4">What Happens Next</h3>
            <div className="space-y-4">
              {[
                {
                  step: 1,
                  title: 'Confirmation Email',
                  description:
                    'You will receive a detailed receipt and tax documentation to your email address within a few minutes.',
                },
                {
                  step: 2,
                  title: 'Processing',
                  description:
                    'Your donation will be processed and allocated to our research, printing, and distribution programs.',
                },
                {
                  step: 3,
                  title: 'Impact Report',
                  description:
                    'We will send you periodic updates on how your donation is making a difference in our communities.',
                },
              ].map((item) => (
                <div key={item.step} className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                    {item.step}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-foreground mb-1">{item.title}</h4>
                    <p className="text-foreground/70 text-sm">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Email Notification */}
          <div className="flex items-start gap-3 p-4 bg-primary/5 rounded-lg border border-primary/20 mb-8">
            <Mail className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div className="text-sm text-left">
              <p className="text-foreground/70">
                A confirmation email has been sent to your email address. Please check your inbox (and
                spam folder) for your receipt and tax documentation.
              </p>
            </div>
          </div>

          {/* Impact Statement */}
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/20 rounded-lg p-8 mb-8">
            <Heart className="w-6 h-6 text-accent mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-foreground mb-2">Your Impact</h3>
            <p className="text-foreground/70 mb-4">
              Through your generous donation, you are helping us:
            </p>
            <ul className="text-sm text-foreground/70 space-y-2 mb-4">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-accent"></span>
                Print high-quality copies of the Holy Quran
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-accent"></span>
                Conduct in-depth Quranic research
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-accent"></span>
                Distribute to communities worldwide
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-accent"></span>
                Support education and spiritual development
              </li>
            </ul>
          </div>

          {/* Call to Action */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Link href="/">Return to Home</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-primary text-primary bg-transparent"
              >
                <Link href="/distribution">See Our Impact</Link>
              </Button>
            </div>

            {/* Share Section */}
            <div className="pt-8 border-t border-border mt-8">
              <p className="text-foreground/70 mb-4">Know someone who cares? Share our mission:</p>
              <div className="flex gap-3 justify-center">
                <button className="px-4 py-2 bg-secondary rounded-lg text-foreground hover:bg-secondary/80 text-sm font-medium transition-colors">
                  Share on Facebook
                </button>
                <button className="px-4 py-2 bg-secondary rounded-lg text-foreground hover:bg-secondary/80 text-sm font-medium transition-colors">
                  Share on Twitter
                </button>
                <button className="px-4 py-2 bg-secondary rounded-lg text-foreground hover:bg-secondary/80 text-sm font-medium transition-colors">
                  Copy Link
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Info */}
      <section className="py-16 px-4 bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-2xl font-bold text-foreground mb-8 text-center">Need Help?</h2>
          <div className="grid sm:grid-cols-3 gap-6">
            {[
              {
                title: 'Donation Assistance',
                description: 'Questions about your donation?',
                link: '/contact',
              },
              {
                title: 'Tax Documentation',
                description: 'Need your tax receipt?',
                link: '/contact',
              },
              {
                title: 'General Inquiries',
                description: 'Contact our support team',
                link: '/contact',
              },
            ].map((item, index) => (
              <div key={index} className="p-6 bg-background rounded-lg border border-border text-center">
                <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-foreground/70 mb-4">{item.description}</p>
                <Button asChild variant="outline" size="sm" className="border-primary text-primary bg-transparent">
                  <Link href={item.link}>Learn More</Link>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
