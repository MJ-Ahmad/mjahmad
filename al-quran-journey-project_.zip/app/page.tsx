import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Zap, Globe, Code, Users, Rocket, TrendingUp, BookOpen, Cpu, Award } from 'lucide-react'
import Image from 'next/image'

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section with Web3 Vision */}
      <section className="relative h-[600px] sm:h-[700px] lg:h-[800px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/images/quran-hero.jpg"
            alt="Holy Quran"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/70"></div>
        </div>
        
        <div className="relative z-10 max-w-5xl mx-auto text-center px-4">
          <div className="inline-block mb-6 px-4 py-3 bg-accent/20 rounded-full border border-accent/50 backdrop-blur-sm">
            <p className="text-sm font-semibold text-accent">Web3 Quranic Future Technology</p>
          </div>
          <h1 className="text-6xl sm:text-7xl lg:text-8xl font-bold text-foreground mb-6 leading-tight text-balance">
            Quantum Quran{' '}
            <span className="bg-gradient-to-r from-accent via-primary to-accent bg-clip-text text-transparent">
              Ecosystem
            </span>
          </h1>
          <p className="text-lg sm:text-xl text-foreground/90 mb-8 max-w-3xl mx-auto leading-relaxed">
            Advanced Web3 platform combining distributed Quranic resources, AI-powered learning, blockchain transparency, 
            and decentralized governance. Tomorrow's technology serving timeless wisdom.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-accent text-foreground hover:bg-accent/90 font-semibold"
            >
              <Link href="/projects">Explore Projects</Link>
            </Button>
            <Button
              asChild
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
            >
              <Link href="/documentation">View Docs</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-24 px-4 bg-gradient-to-b from-secondary/30 to-background">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <h2 className="text-5xl font-bold text-foreground mb-4 text-balance">Our Web3 Mission</h2>
          <p className="text-xl text-foreground/70 max-w-3xl mx-auto leading-relaxed">
            Revolutionizing Quranic knowledge distribution through decentralized technology, enabling transparent governance, 
            peer-to-peer learning, and global community-driven initiatives.
          </p>
        </div>

        <div className="max-w-7xl mx-auto grid lg:grid-cols-3 gap-8">
          {[
            {
              icon: Cpu,
              title: 'Quantum Learning',
              description: 'AI-powered adaptive learning systems optimized for Quranic memorization (Hifz) with personalized pathways.',
            },
            {
              icon: Globe,
              title: 'Decentralized Resources',
              description: 'Community-maintained archives, telawat recordings, translations, and scholarship across distributed nodes.',
            },
            {
              icon: Zap,
              title: 'Blockchain Transparency',
              description: 'Immutable donation tracking, verifiable impact metrics, and transparent fund distribution via smart contracts.',
            },
          ].map((item, i) => {
            const Icon = item.icon
            return (
              <div key={i} className="p-8 bg-background rounded-xl border border-border hover:border-primary/50 transition-all hover:shadow-xl hover:-translate-y-1">
                <Icon className="w-12 h-12 text-accent mb-4" />
                <h3 className="text-2xl font-bold text-foreground mb-3">{item.title}</h3>
                <p className="text-foreground/70 leading-relaxed">{item.description}</p>
              </div>
            )
          })}
        </div>
      </section>

      {/* Core Initiatives */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl font-bold text-foreground mb-4 text-center text-balance">Core Initiatives</h2>
          <p className="text-xl text-foreground/70 text-center mb-16 max-w-2xl mx-auto">
            Click to explore our interconnected Web3 projects and initiatives
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Resource Hub',
                description: 'Distributed archive of Quran texts, telawat recordings, translations, and scholarly works',
                href: '/resources',
                icon: '📚',
              },
              {
                title: 'Printing & Distribution',
                description: 'Transparent supply chain tracking and community-driven printing partnerships',
                href: '/production',
                icon: '🖨️',
              },
              {
                title: 'Learning Platform',
                description: 'AI-assisted Hifz learning, Tajweed tutoring, and personalized educational journeys',
                href: '/learning',
                icon: '🎓',
              },
            ].map((item, i) => (
              <Link key={i} href={item.href} className="group">
                <div className="h-full p-8 bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl border border-primary/20 hover:border-primary/50 transition-all hover:shadow-xl hover:-translate-y-1">
                  <div className="text-5xl mb-4">{item.icon}</div>
                  <h3 className="text-2xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">{item.title}</h3>
                  <p className="text-foreground/70 mb-6">{item.description}</p>
                  <div className="flex items-center gap-2 text-primary font-semibold group-hover:translate-x-2 transition-transform">
                    Explore <Rocket className="w-4 h-4" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Collective Impact */}
      <section className="py-24 px-4 bg-gradient-to-br from-secondary/50 to-background">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl font-bold text-foreground mb-16 text-center text-balance">Our Collective Impact</h2>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: 'Qurans Gifted', value: '170K+', icon: '📖' },
              { label: 'Students Served', value: '5M+', icon: '👨‍🎓' },
              { label: 'Contributors', value: '500+', icon: '👥' },
              { label: 'Countries Reached', value: '50+', icon: '🌍' },
            ].map((stat, i) => (
              <div key={i} className="p-8 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/20 text-center">
                <div className="text-5xl mb-3">{stat.icon}</div>
                <div className="text-4xl font-bold text-foreground mb-2">{stat.value}</div>
                <p className="text-foreground/70 font-semibold">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Learning Resources */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl font-bold text-foreground mb-4 text-center text-balance">Learning Resources</h2>
          <p className="text-xl text-foreground/70 text-center mb-16 max-w-2xl mx-auto">
            Comprehensive ecosystem for Quranic study, memorization, and spiritual development
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: 'Telawat Learning',
                items: ['Audio-visual recitations', 'Tajweed guides', 'Multiple qaris', 'Interactive lessons'],
              },
              {
                title: 'Hifz Academy',
                items: ['Personalized schedules', 'AI tutoring', 'Progress tracking', 'Community support'],
              },
              {
                title: 'Translations Archive',
                items: ['Multi-language support', 'Scholarly commentary', 'Thematic search', 'Version control'],
              },
              {
                title: 'Research Library',
                items: ['Academic papers', 'Hadith collections', 'Historical context', 'Expert resources'],
              },
            ].map((section, i) => (
              <div key={i} className="p-8 rounded-xl border border-border hover:border-primary/50 transition-all">
                <h3 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <BookOpen className="w-6 h-6 text-accent" />
                  {section.title}
                </h3>
                <ul className="space-y-3">
                  {section.items.map((item, j) => (
                    <li key={j} className="flex items-center gap-3 text-foreground/80">
                      <span className="w-2 h-2 bg-primary rounded-full"></span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Project Progress */}
      <section className="py-24 px-4 bg-gradient-to-b from-secondary/30 to-background">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl font-bold text-foreground mb-4 text-center text-balance">Project Progress</h2>
          <p className="text-xl text-foreground/70 text-center mb-16 max-w-2xl mx-auto">
            Transparent tracking of milestones, contributions, and upcoming phases
          </p>

          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {[
              { label: 'Q1 2026: Foundation', status: 'In Progress', progress: 75 },
              { label: 'Q2 2026: Web3 Integration', status: 'Planning', progress: 30 },
              { label: 'Q3 2026: Global Launch', status: 'Planned', progress: 10 },
            ].map((item, i) => (
              <div key={i} className="p-6 rounded-xl border border-border">
                <h3 className="font-bold text-foreground mb-2">{item.label}</h3>
                <p className="text-sm text-foreground/60 mb-4">{item.status}</p>
                <div className="w-full bg-secondary rounded-full h-3 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500"
                    style={{ width: `${item.progress}%` }}
                  ></div>
                </div>
                <p className="text-sm text-foreground/70 mt-2 font-semibold">{item.progress}% Complete</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contributors */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl font-bold text-foreground mb-16 text-center text-balance">Our Contributors</h2>

          <div className="grid gap-8 mb-16">
            {/* Featured */}
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
                <span className="text-accent">★</span> Featured Contributors
              </h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {Array(4)
                  .fill(null)
                  .map((_, i) => (
                    <div key={i} className="p-6 bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl border border-primary/20 text-center">
                      <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-full mx-auto mb-4"></div>
                      <p className="font-bold text-foreground">Contributor {i + 1}</p>
                      <p className="text-sm text-foreground/60">Lead Developer</p>
                    </div>
                  ))}
              </div>
            </div>

            {/* Top Contributors */}
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-accent" /> Top Contributors
              </h3>
              <div className="space-y-3">
                {Array(5)
                  .fill(null)
                  .map((_, i) => (
                    <div key={i} className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg hover:bg-secondary transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full"></div>
                        <p className="font-semibold text-foreground">Contributor Name</p>
                      </div>
                      <span className="text-accent font-bold">{(i + 1) * 25} contributions</span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Investment Opportunities */}
      <section className="py-24 px-4 bg-gradient-to-br from-secondary/50 to-background">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl font-bold text-foreground mb-4 text-center text-balance">Investment Opportunities</h2>
          <p className="text-xl text-foreground/70 text-center mb-12 max-w-2xl mx-auto">
            Support our Web3 Quranic ecosystem through various investment channels
          </p>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                title: 'Direct Donations',
                icon: '💝',
                description: 'One-time or recurring contributions supporting all initiatives',
              },
              {
                title: 'Sponsorships',
                icon: '🤝',
                description: 'Strategic partnerships with institutions and enterprises',
              },
              {
                title: 'Grants & Funding',
                icon: '💰',
                description: 'Institutional grants and impact investment opportunities',
              },
            ].map((item, i) => (
              <Link key={i} href="/support" className="group">
                <div className="h-full p-8 bg-background border border-border hover:border-primary/50 rounded-xl transition-all hover:shadow-xl">
                  <div className="text-5xl mb-4">{item.icon}</div>
                  <h3 className="text-2xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">{item.title}</h3>
                  <p className="text-foreground/70">{item.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Join Community */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl font-bold text-foreground mb-16 text-center text-balance">Join the QuranerFariwala Community</h2>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Contribute Code',
                description: 'Help build our Web3 platform, AI systems, and learning tools',
                href: '/community',
                icon: Code,
              },
              {
                title: 'Join a Project',
                description: 'Participate in research, translations, or community initiatives',
                href: '/projects',
                icon: Rocket,
              },
              {
                title: 'Share Knowledge',
                description: 'Contribute as a teacher, scholar, or community mentor',
                href: '/community',
                icon: Users,
              },
            ].map((item, i) => {
              const Icon = item.icon
              return (
                <Link key={i} href={item.href} className="group">
                  <div className="h-full p-8 bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 hover:border-primary/50 rounded-xl transition-all hover:shadow-xl hover:-translate-y-1">
                    <Icon className="w-12 h-12 text-accent mb-4" />
                    <h3 className="text-2xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">{item.title}</h3>
                    <p className="text-foreground/70 mb-6">{item.description}</p>
                    <div className="flex items-center gap-2 text-primary font-semibold group-hover:translate-x-2 transition-transform">
                      Get Started <Rocket className="w-4 h-4" />
                    </div>
                  </div>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA Section - Updated */}
      <section className="py-24 px-4 bg-gradient-to-r from-primary via-primary/90 to-accent text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-5xl font-bold mb-6 text-balance">Begin Your Web3 Quranic Journey</h2>
          <p className="text-xl text-primary-foreground/90 mb-12 leading-relaxed">
            Join a global community building tomorrow's Quranic ecosystem with transparency, 
            innovation, and spiritual purpose at its core.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-accent text-foreground hover:bg-accent/90 font-semibold text-lg"
            >
              <Link href="/projects">Explore Ecosystem</Link>
            </Button>
            <Button
              asChild
              size="lg"
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 font-semibold text-lg"
            >
              <Link href="/documentation">View Documentation</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Production Process Section */}
      <section className="py-24 px-4 bg-gradient-to-br from-secondary/30 to-background">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-foreground mb-4">Our Production Process</h2>
            <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
              From manuscript to student hands — a 6-step journey of excellence and precision
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {[
              {
                step: '01',
                title: 'Research & Curation',
                description: 'Scholars authenticate and curate Quranic texts using academic rigor and Islamic principles.',
              },
              {
                step: '02',
                title: 'Design & Layout',
                description: 'Expert designers optimize pages for memorization with clear typography and ideal spacing.',
              },
              {
                step: '03',
                title: 'Printing Technology',
                description: 'State-of-the-art machinery produces pristine copies with vibrant colors and sharp details.',
              },
              {
                step: '04',
                title: 'Quality Inspection',
                description: 'Every copy undergoes rigorous multi-point quality checks to ensure perfection.',
              },
              {
                step: '05',
                title: 'Binding & Finishing',
                description: 'Professional binding and finishing creates durable, beautiful books built to last.',
              },
              {
                step: '06',
                title: 'Global Distribution',
                description: 'Secure packaging and tracked logistics deliver Qurans to students worldwide.',
              },
            ].map((item, index) => (
              <div
                key={index}
                className="group p-8 bg-background rounded-xl border border-border hover:border-primary/50 transition-all hover:-translate-y-2 hover:shadow-lg"
              >
                <div className="text-5xl font-bold text-accent/30 group-hover:text-accent/60 transition-colors mb-4">
                  {item.step}
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-3">{item.title}</h3>
                <p className="text-foreground/70 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>

          {/* Process Flow Image */}
          <div className="relative h-96 rounded-xl overflow-hidden border-2 border-primary/30 shadow-2xl">
            <Image
              src="/images/hifz-students.jpg"
              alt="Students with Quran"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent flex items-end p-8">
              <div className="max-w-2xl">
                <h3 className="text-3xl font-bold text-foreground mb-2">Impact: Every Page Counts</h3>
                <p className="text-lg text-foreground/90">
                  Our production excellence directly impacts Hifz students' learning outcomes and spiritual journey.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section with Gradient */}
      <section className="py-24 px-4 bg-gradient-to-r from-primary via-primary/90 to-accent text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-5xl font-bold mb-6 text-balance">Join Ramadhan-2026 Revival</h2>
          <p className="text-xl text-primary-foreground/90 mb-12 leading-relaxed">
            Help us print and distribute 40,000 memorization-optimized Qurans to orphans and Hifz centres 
            across Bangladesh and South Asia. Your support transforms lives.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-accent text-foreground hover:bg-accent/90 font-semibold text-lg"
            >
              <Link href="/donate">Donate Now</Link>
            </Button>
            <Button
              asChild
              size="lg"
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 font-semibold text-lg"
            >
              <Link href="/sponsorship-tracker">View Impact</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
