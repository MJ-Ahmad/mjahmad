'use client'

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { 
  BookOpen, Globe, Users, TrendingUp, FileText, Share2, 
  Zap, Check, BarChart3, Shield, Heart, Briefcase 
} from 'lucide-react'
import Link from 'next/link'

export default function Features() {
  const features = [
    {
      icon: Globe,
      title: 'Ramadhan-2026 Campaign',
      description: 'Complete pitch deck for 40,000 Qur\'an distribution campaign with global sponsorship pathways',
      link: '/pitch-deck',
      tags: ['Campaign', 'Sponsorship', 'Global']
    },
    {
      icon: Users,
      title: 'Organization Profile',
      description: 'Complete about page with legal registration, contact info, payment methods, and vision',
      link: '/about',
      tags: ['About', 'Contact', 'Legal']
    },
    {
      icon: BarChart3,
      title: 'Sponsorship Tracker',
      description: 'Auditor-ready dashboard with real-time metrics, donation tracking, and compliance reporting',
      link: '/sponsorship-tracker',
      tags: ['Analytics', 'Tracking', 'Audit']
    },
    {
      icon: Share2,
      title: 'Social Media Kit',
      description: 'Branded assets, copy templates, hashtags, and design guidelines for campaign amplification',
      link: '/social-media-kit',
      tags: ['Marketing', 'Branding', 'Social']
    },
    {
      icon: Heart,
      title: 'Donation System',
      description: 'Multiple sponsorship tiers with real payment methods (bKash, banks, MetaMask, multi-currency)',
      link: '/donate',
      tags: ['Donations', 'Payment', 'Commerce']
    },
    {
      icon: Briefcase,
      title: 'Project Portfolio',
      description: 'Overview of all active projects, initiatives, and impact metrics across the organization',
      link: '/projects',
      tags: ['Projects', 'Overview', 'Impact']
    },
    {
      icon: BookOpen,
      title: 'Gallery & Production',
      description: 'Visual showcase of printing process, distribution, and community impact',
      link: '/gallery',
      tags: ['Gallery', 'Media', 'Process']
    },
    {
      icon: FileText,
      title: 'Legal & Compliance',
      description: 'Complete legal pages including privacy policy, terms of service, and FAQ',
      link: '/faq',
      tags: ['Legal', 'Info', 'Help']
    },
    {
      icon: Zap,
      title: 'Contact & Support',
      description: 'Direct contact form, email, phone, and social media links with response times',
      link: '/contact',
      tags: ['Support', 'Contact', 'Help']
    },
  ]

  const improvements = [
    {
      title: 'Real Organizational Data',
      description: 'Full integration of Quraner Fariwala details: UK registration, contact info, bank accounts',
      icon: Check
    },
    {
      title: 'Professional Branding',
      description: 'Custom color palette (green #7B7D4A + gold #FFE4A1), typography, and design system',
      icon: Check
    },
    {
      title: 'Campaign-Ready Pages',
      description: 'Comprehensive pitch deck, sponsorship tracker, and social media kit for fundraising',
      icon: Check
    },
    {
      title: 'Multi-Currency Support',
      description: 'Support for USD, GBP, EUR, CAD, AUD, SAR, and BDT with real payment methods',
      icon: Check
    },
    {
      title: 'Audit-Ready Tracking',
      description: 'Comprehensive dashboard with real-time metrics, donor registry, and compliance reports',
      icon: Check
    },
    {
      title: 'Transparent Communication',
      description: 'Detailed about page, FAQ, legal documents, and contact information',
      icon: Check
    },
    {
      title: 'Social Media Integration',
      description: 'Branded content kit with taglines, hashtags, copy templates, and design guidelines',
      icon: Check
    },
    {
      title: 'Responsive Navigation',
      description: 'Updated header and footer with all new pages and organizational links',
      icon: Check
    },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-5xl font-bold text-foreground mb-4">Complete Website Features</h1>
          <p className="text-xl text-foreground/70 max-w-2xl">
            All pages, features, and integrations for the Quraner Fariwala website with real organizational 
            data, professional branding, and campaign-ready tools.
          </p>
        </div>
      </section>

      {/* Key Features */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Key Pages & Features</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <Card key={index} className="p-6 hover:border-primary/50 transition-all group">
                  <Icon className="w-10 h-10 text-primary mb-4 group-hover:scale-110 transition-transform" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-foreground/70 text-sm mb-4">{feature.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {feature.tags.map((tag, tIndex) => (
                      <span key={tIndex} className="inline-block px-2 py-1 bg-primary/10 text-primary text-xs rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <Button asChild variant="outline" className="w-full text-sm bg-transparent">
                    <Link href={feature.link}>Visit Page</Link>
                  </Button>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Improvements Made */}
      <section className="py-20 px-4 bg-secondary/20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Comprehensive Updates</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {improvements.map((item, index) => {
              const Icon = item.icon
              return (
                <Card key={index} className="p-6 flex gap-4">
                  <Icon className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                    <p className="text-foreground/70 text-sm">{item.description}</p>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Organization Info */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Organization Information</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8">
              <h3 className="text-xl font-semibold text-primary mb-4">Quraner Fariwala</h3>
              <ul className="space-y-3 text-foreground/70 text-sm">
                <li><strong>Region:</strong> Bangladesh-based, UK-registered</li>
                <li><strong>Registration:</strong> Reg. 14066998, SIC 85600</li>
                <li><strong>TRAD License:</strong> DSCC/03727/2021</li>
                <li><strong>Focus:</strong> Research, Printing, Distribution of Holy Quran</li>
                <li><strong>Students Served:</strong> 5,000,000+ Hifz learners</li>
                <li><strong>Founder:</strong> MJ Ahmad (System Architect, Visionary Steward)</li>
              </ul>
            </Card>

            <Card className="p-8">
              <h3 className="text-xl font-semibold text-primary mb-4">Contact & Payment</h3>
              <div className="space-y-4 text-sm text-foreground/70">
                <div>
                  <p className="font-semibold text-foreground mb-1">Address</p>
                  <p>27 Purana Paltan, Paltan, Dhaka-1000, Bangladesh</p>
                </div>
                <div>
                  <p className="font-semibold text-foreground mb-1">Email</p>
                  <p>quranerfariwala@gmail.com</p>
                </div>
                <div>
                  <p className="font-semibold text-foreground mb-1">Phone</p>
                  <p>+880-1788856628</p>
                </div>
                <div>
                  <p className="font-semibold text-foreground mb-1">Accepted Methods</p>
                  <p>bKash, Multiple BD Banks, MetaMask, Multi-currency Gateway (Coming Soon)</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Campaign Info */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold mb-8">Featured Campaign: Ramadhan-2026</h2>
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <p className="text-accent font-semibold mb-2">Campaign Goal</p>
              <p className="text-3xl font-bold">40,000 Qurans</p>
              <p className="text-sm text-primary-foreground/70">Memorization-optimized</p>
            </div>
            <div>
              <p className="text-accent font-semibold mb-2">Budget Required</p>
              <p className="text-3xl font-bold">$146,500</p>
              <p className="text-sm text-primary-foreground/70">16.2M BDT / £120,000</p>
            </div>
            <div>
              <p className="text-accent font-semibold mb-2">Target Impact</p>
              <p className="text-3xl font-bold">10,000+</p>
              <p className="text-sm text-primary-foreground/70">Orphans & Underserved</p>
            </div>
          </div>
          <Button asChild size="lg" className="bg-accent text-foreground hover:bg-accent/90">
            <Link href="/pitch-deck">View Campaign Details</Link>
          </Button>
        </div>
      </section>

      {/* Quick Links */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Quick Navigation</h2>
          <div className="grid md:grid-cols-4 gap-4">
            <Button asChild variant="outline" className="h-auto py-4 flex-col bg-transparent">
              <Link href="/donate">
                <Heart className="w-6 h-6 mb-2" />
                Support Campaign
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-auto py-4 flex-col bg-transparent">
              <Link href="/pitch-deck">
                <FileText className="w-6 h-6 mb-2" />
                Pitch Deck
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-auto py-4 flex-col bg-transparent">
              <Link href="/sponsorship-tracker">
                <BarChart3 className="w-6 h-6 mb-2" />
                Tracker
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-auto py-4 flex-col bg-transparent">
              <Link href="/social-media-kit">
                <Share2 className="w-6 h-6 mb-2" />
                Social Kit
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
