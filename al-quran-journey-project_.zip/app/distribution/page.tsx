import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { Globe, MapPin, Users } from 'lucide-react'

const distributionRegions = [
  {
    region: 'South Asia',
    countries: 'Pakistan, Bangladesh, India',
    centers: 15,
    copiesDistributed: '12000+',
  },
  {
    region: 'Middle East',
    countries: 'Saudi Arabia, UAE, Jordan',
    centers: 22,
    copiesDistributed: '18000+',
  },
  {
    region: 'Europe',
    countries: 'UK, Germany, France',
    centers: 12,
    copiesDistributed: '8000+',
  },
  {
    region: 'North America',
    countries: 'USA, Canada',
    centers: 18,
    copiesDistributed: '10000+',
  },
  {
    region: 'Africa',
    countries: 'Egypt, Nigeria, Kenya',
    centers: 16,
    copiesDistributed: '9000+',
  },
  {
    region: 'Southeast Asia',
    countries: 'Indonesia, Malaysia, Thailand',
    centers: 14,
    copiesDistributed: '7000+',
  },
]

export default function DistributionPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-4">
            Global Distribution Network
          </h1>
          <p className="text-lg text-foreground/70 max-w-2xl">
            Through our extensive network, we ensure the Holy Quran reaches communities across
            every corner of the world.
          </p>
        </div>
      </section>

      {/* Distribution Methods */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">How We Distribute</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: MapPin,
                title: 'Physical Distribution Centers',
                description:
                  'Established distribution hubs in major cities and communities, making Qurans easily accessible to all.',
              },
              {
                icon: Users,
                title: 'Community Partnerships',
                description:
                  'Working with mosques, educational institutions, and community organizations for grassroots reach.',
              },
              {
                icon: Globe,
                title: 'International Outreach',
                description:
                  'Coordinated efforts with global partners to ensure worldwide distribution and accessibility.',
              },
            ].map((method, index) => {
              const Icon = method.icon
              return (
                <div
                  key={index}
                  className="p-8 bg-background rounded-lg border border-border hover:border-primary/30 transition-colors"
                >
                  <Icon className="w-8 h-8 text-primary mb-4" />
                  <h3 className="text-xl font-semibold text-foreground mb-3">{method.title}</h3>
                  <p className="text-foreground/70">{method.description}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Global Regions */}
      <section className="py-20 px-4 bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-4 text-center">Our Global Presence</h2>
          <p className="text-center text-foreground/70 mb-12 max-w-2xl mx-auto">
            We operate in multiple regions across the world with dedicated distribution centers and
            community partnerships.
          </p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {distributionRegions.map((region, index) => (
              <div key={index} className="p-6 bg-background rounded-lg border border-border">
                <h3 className="text-lg font-bold text-primary mb-2">{region.region}</h3>
                <p className="text-sm text-foreground/70 mb-4">{region.countries}</p>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-foreground/70">Distribution Centers:</span>
                    <span className="font-semibold text-foreground">{region.centers}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-foreground/70">Copies Distributed:</span>
                    <span className="font-semibold text-foreground">{region.copiesDistributed}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Distribution Process */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">Our Distribution Process</h2>
          <div className="space-y-8">
            {[
              {
                step: 'Partner Engagement',
                description:
                  'Identifying and establishing relationships with trustworthy organizations in target communities.',
              },
              {
                step: 'Needs Assessment',
                description: 'Understanding local needs and preferences for distribution methods.',
              },
              {
                step: 'Strategic Placement',
                description: 'Placing Qurans in accessible locations including mosques, centers, and libraries.',
              },
              {
                step: 'Community Engagement',
                description: 'Working closely with communities to ensure effective and respectful distribution.',
              },
              {
                step: 'Feedback & Support',
                description:
                  'Collecting feedback and providing ongoing support to ensure satisfaction and impact.',
              },
              {
                step: 'Impact Tracking',
                description: 'Monitoring and documenting the positive impact of our distribution efforts.',
              },
            ].map((item, index) => (
              <div key={index} className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-full bg-primary text-primary-foreground font-bold">
                    {index + 1}
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground mb-1">{item.step}</h3>
                  <p className="text-foreground/70">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Statistics */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold mb-4 text-center">Our Impact</h2>
          <p className="text-center text-primary-foreground/90 mb-12">
            Through our dedicated efforts, we've made a significant impact in spreading the Holy
            Quran globally.
          </p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {[
              { stat: '6', label: 'Continents Reached' },
              { stat: '97', label: 'Countries' },
              { stat: '115+', label: 'Distribution Centers' },
              { stat: '64K+', label: 'Total Distributed' },
            ].map((item, index) => (
              <div key={index}>
                <div className="text-4xl font-bold mb-2 text-accent">{item.stat}</div>
                <p className="text-primary-foreground/90">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 bg-secondary/30">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">Expand Our Reach</h2>
          <p className="text-foreground/70 mb-8">
            Help us distribute the Holy Quran to more communities. Your support makes a real
            difference.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Link href="/donate">Support Distribution</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-primary text-primary bg-transparent">
              <Link href="/get-involved">Get Involved</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
