'use client'

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Globe, Users, TrendingUp, BookOpen, Award, Target } from 'lucide-react'
import Link from 'next/link'

export default function Projects() {
  const projects = [
    {
      icon: Globe,
      title: 'Ramadhan-2026 Global Revival',
      status: 'Active Campaign',
      description: 'Print and distribute 40,000 memorization-optimized Qurans across Bangladesh and South Asia.',
      impact: '40,000 Qurans | 10,000+ Orphans | 1,000+ Institutions',
      features: ['Multi-currency donations', 'Global sponsorship pathways', 'Monthly reporting', 'Auditor-ready tracking'],
      link: '/pitch-deck'
    },
    {
      icon: Users,
      title: 'Institutional Infrastructure',
      status: 'In Progress',
      description: 'Restore printing facilities, settle legacy debts, and strengthen team capacity.',
      impact: '$16M+ Institutional Investment | 2-Year Sustainability Plan',
      features: ['Debt recovery programs', 'Technology upgrades', 'Team development', 'Facility modernization'],
      link: '/about'
    },
    {
      icon: BookOpen,
      title: 'Research & Scholarship',
      status: 'Ongoing',
      description: 'Conduct in-depth research on Quranic texts and memorization methodologies.',
      impact: 'Publications | Educational Resources | Teacher Training',
      features: ['Scholarly articles', 'Pedagogical tools', 'Digital library', 'Educational programs'],
      link: '/production'
    },
    {
      icon: TrendingUp,
      title: 'Global Distribution Network',
      status: 'Expanding',
      description: 'Establish distribution channels across Bangladesh, South Asia, and diaspora communities.',
      impact: '170K+ Gifts (2 Years) | 5M+ Students Reached',
      features: ['Regional hubs', 'Community partnerships', 'Logistics optimization', 'Impact tracking'],
      link: '/distribution'
    },
    {
      icon: Award,
      title: 'Quality & Compliance',
      status: 'Active',
      description: 'Maintain ethical standards, transparency, and audit-ready documentation.',
      impact: 'UK Registration | Full Compliance | Donor Trust',
      features: ['Monthly audits', 'Distribution registry', 'Impact reports', 'Transparency portal'],
      link: '/sponsorship-tracker'
    },
    {
      icon: Target,
      title: 'Community Engagement',
      status: 'Growing',
      description: 'Amplify campaign reach through social media, partnerships, and grassroots outreach.',
      impact: '470+ Sponsors | 6+ Currencies | Multi-platform Presence',
      features: ['Branded content kit', 'Social campaigns', 'Donor portal', 'Newsletter'],
      link: '/social-media-kit'
    }
  ]

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-5xl font-bold text-foreground mb-4">Our Projects</h1>
          <p className="text-xl text-foreground/70 max-w-2xl">
            Strategic initiatives advancing the mission of Quraner Fariwala across research, production, 
            distribution, and community engagement.
          </p>
        </div>
      </section>

      {/* Featured Campaign */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <Card className="p-8 md:p-12 bg-gradient-to-r from-primary/5 to-accent/5 border-2 border-primary/20">
            <div className="flex items-start gap-4 mb-6">
              <div className="inline-block px-4 py-2 bg-accent/30 rounded-full">
                <p className="text-sm font-semibold text-accent">Featured Campaign</p>
              </div>
            </div>
            <h2 className="text-4xl font-bold text-foreground mb-4">Ramadhan-2026: Global Revival</h2>
            <p className="text-lg text-foreground/70 mb-8">
              Our flagship campaign to print and distribute 40,000 memorization-optimized Qurans 
              by January 2026, prioritizing orphans and underserved Hifz centres across South Asia.
            </p>
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div>
                <p className="text-sm text-foreground/60 mb-1">Campaign Goal</p>
                <p className="text-2xl font-bold text-primary">40,000 Qurans</p>
              </div>
              <div>
                <p className="text-sm text-foreground/60 mb-1">Budget Required</p>
                <p className="text-2xl font-bold text-accent">$146,500</p>
              </div>
              <div>
                <p className="text-sm text-foreground/60 mb-1">Current Progress</p>
                <p className="text-2xl font-bold text-primary">99.3% Funded</p>
              </div>
            </div>
            <div className="flex gap-4">
              <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Link href="/pitch-deck">View Full Pitch Deck</Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/donate">Support Campaign</Link>
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* All Projects */}
      <section className="py-20 px-4 bg-secondary/20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Active Projects</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {projects.filter(p => p.title !== 'Ramadhan-2026 Global Revival').map((project, index) => {
              const Icon = project.icon
              return (
                <Card key={index} className="p-8 hover:border-primary/50 transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <Icon className="w-10 h-10 text-primary" />
                    <span className="inline-block px-3 py-1 bg-primary/10 rounded-full text-xs font-semibold text-primary">
                      {project.status}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-2">{project.title}</h3>
                  <p className="text-foreground/70 mb-4">{project.description}</p>
                  <div className="mb-6 p-4 bg-secondary rounded-lg">
                    <p className="text-sm font-semibold text-primary">{project.impact}</p>
                  </div>
                  <div className="mb-6">
                    <p className="text-xs text-foreground/60 mb-2">Key Features</p>
                    <ul className="space-y-1 text-sm text-foreground/70">
                      {project.features.map((feature, fIndex) => (
                        <li key={fIndex} className="flex items-center gap-2">
                          <span className="w-1 h-1 bg-primary rounded-full" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Button asChild variant="outline" className="w-full bg-transparent">
                    <Link href={project.link}>Learn More</Link>
                  </Button>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Impact Metrics */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Cumulative Impact</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="p-8 text-center border-t-4 border-t-primary">
              <p className="text-4xl font-bold text-primary mb-2">170K+</p>
              <p className="text-foreground/70 font-medium">Qurans Gifted</p>
              <p className="text-xs text-foreground/60 mt-2">(Last 2 Years)</p>
            </Card>
            <Card className="p-8 text-center border-t-4 border-t-accent">
              <p className="text-4xl font-bold text-accent mb-2">5M+</p>
              <p className="text-foreground/70 font-medium">Hifz Students</p>
              <p className="text-xs text-foreground/60 mt-2">Served Across Bangladesh</p>
            </Card>
            <Card className="p-8 text-center border-t-4 border-t-primary">
              <p className="text-4xl font-bold text-primary mb-2">6</p>
              <p className="text-foreground/70 font-medium">Editions Published</p>
              <p className="text-xs text-foreground/60 mt-2">(2020-2025)</p>
            </Card>
            <Card className="p-8 text-center border-t-4 border-t-accent">
              <p className="text-4xl font-bold text-accent mb-2">1000+</p>
              <p className="text-foreground/70 font-medium">Institutions</p>
              <p className="text-xs text-foreground/60 mt-2">Reached Worldwide</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Get Involved */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Get Involved Today</h2>
          <p className="text-xl text-primary-foreground/90 mb-8">
            Join our mission to spread the Holy Quran. Whether through sponsorship, partnership, 
            or amplifying our message, your support transforms lives.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-accent text-foreground hover:bg-accent/90">
              <Link href="/donate">Donate Now</Link>
            </Button>
            <Button asChild size="lg" variant="outline"
              className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 bg-transparent">
              <Link href="/contact">Contact Us</Link>
            </Button>
            <Button asChild size="lg" variant="outline"
              className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 bg-transparent">
              <Link href="/social-media-kit">Share Campaign</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
