'use client'

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const faqs = [
  {
    category: 'About Quraner Fariwala',
    items: [
      {
        question: 'What is Quraner Fariwala?',
        answer:
          'Quraner Fariwala Ltd is Bangladesh\'s largest Quran printing company and a UK-registered educational support organization (Reg. 14066998, SIC 85600). We serve over 5 million Hifz students, orphans, and underprivileged learners with memorization-optimized Qurans and trauma-informed educational support.',
      },
      {
        question: 'Is Quraner Fariwala a charity or a business?',
        answer:
          'We are a mission-driven printing company with a hybrid structure: operationally commercial, spiritually nonprofit. All surplus is reinvested into Quran distribution, educational justice, and legacy stewardship. We are UK-registered and fully transparent.',
      },
      {
        question: 'Who founded Quraner Fariwala?',
        answer:
          'The organization was founded by MJ Ahmad, a visionary steward and system architect committed to ethical inheritance, donor transparency, and trauma-informed education. Our mission focuses on serving 5+ million Hifz students across Bangladesh.',
      },
    ],
  },
  {
    category: 'Donations & Sponsorships',
    items: [
      {
        question: 'How do I make a donation?',
        answer:
          'You can make a donation through our website by visiting the "Donate" page. Select your donation amount or custom amount, add items to your cart, and proceed through our secure checkout process.',
      },
      {
        question: 'Is my donation tax-deductible?',
        answer:
          'We are a registered non-profit organization. Donations may be tax-deductible. You will receive tax documentation with your donation receipt. Please consult with your tax advisor for your specific circumstances.',
      },
      {
        question: 'What payment methods do you accept?',
        answer:
          'We accept major credit and debit cards including Visa, MasterCard, and American Express. All payments are processed through a secure payment gateway with industry-standard encryption.',
      },
      {
        question: 'Can I make a recurring donation?',
        answer:
          'Currently, we process one-time donations through our website. For information about setting up recurring donations, please contact our team directly.',
      },
      {
        question: 'How is my donation used?',
        answer:
          'Your donation supports our three core activities: research on Quranic texts, printing high-quality copies, and distributing them to communities worldwide. Each donation option specifies its intended use.',
      },
    ],
  },
  {
    category: 'Our Work',
    items: [
      {
        question: 'What quality standards do you maintain?',
        answer:
          'We maintain rigorous quality standards including manuscript verification, professional printing with premium materials, thorough proofreading, and quality assurance inspections on every copy.',
      },
      {
        question: 'Where are your Qurans distributed?',
        answer:
          'We have distribution centers across 97 countries on 6 continents including South Asia, Middle East, Europe, North America, Africa, and Southeast Asia. See our Distribution page for more details.',
      },
      {
        question: 'How do you ensure accuracy of the text?',
        answer:
          'We cross-verify every manuscript with authenticated scholarly sources. Our team includes Quranic scholars who verify textual accuracy, and we conduct comprehensive proofreading before printing.',
      },
    ],
  },
  {
    category: 'Research',
    items: [
      {
        question: 'What kind of research do you conduct?',
        answer:
          'We conduct comprehensive scholarly research on Quranic texts including historical studies, linguistic analysis, comparative studies, and publication of academic papers. Our research contributes to deeper understanding of the Quranic text.',
      },
      {
        question: 'Are your research publications available?',
        answer:
          'Yes, we have published over 100 research articles and papers. Many are available on our website and through academic institutions. Contact us for specific research inquiries.',
      },
    ],
  },
  {
    category: 'Account & Security',
    items: [
      {
        question: 'Is my personal information secure?',
        answer:
          'Yes, we use industry-standard SSL encryption to protect all personal and payment information. Your data is never stored on our servers after transaction completion.',
      },
      {
        question: 'How do I get my tax receipt?',
        answer:
          'You will receive your tax receipt via email immediately after your donation is processed. If you do not receive it, please check your spam folder or contact our support team.',
      },
      {
        question: 'Can I update my donation preferences?',
        answer:
          'For questions about updating preferences or making changes to your donation, please contact our support team directly with your confirmation number.',
      },
    ],
  },
  {
    category: 'Contact & Support',
    items: [
      {
        question: 'How do I contact AlQuranJourney?',
        answer:
          'You can reach our support team through our contact page, email, or phone. We typically respond within 24-48 hours during business days.',
      },
      {
        question: 'I have a question not listed here. How can I get help?',
        answer:
          'Please visit our Contact page to get in touch with our team. We are happy to answer any questions about our mission, work, or how you can support us.',
      },
    ],
  },
]

function FAQItem({
  question,
  answer,
}: {
  question: string
  answer: string
}) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-6 py-4 flex items-center justify-between bg-background hover:bg-secondary/50 transition-colors text-left"
      >
        <h3 className="font-semibold text-foreground">{question}</h3>
        <ChevronDown
          className={`w-5 h-5 text-primary flex-shrink-0 transition-transform ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>
      {isOpen && (
        <div className="px-6 py-4 bg-secondary/30 border-t border-border">
          <p className="text-foreground/70 leading-relaxed">{answer}</p>
        </div>
      )}
    </div>
  )
}

export default function FAQPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-4">
            Frequently Asked Questions
          </h1>
          <p className="text-lg text-foreground/70">
            Find answers to common questions about AlQuranJourney, our mission, donations, and
            support.
          </p>
        </div>
      </section>

      {/* FAQ Sections */}
      <section className="flex-1 py-20 px-4">
        <div className="max-w-4xl mx-auto">
          {faqs.map((section, sectionIndex) => (
            <div key={sectionIndex} className="mb-12">
              <h2 className="text-2xl font-bold text-foreground mb-6">{section.category}</h2>
              <div className="space-y-4">
                {section.items.map((item, itemIndex) => (
                  <FAQItem key={itemIndex} question={item.question} answer={item.answer} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 px-4 bg-secondary/30">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">Didn't find your answer?</h2>
          <p className="text-foreground/70 mb-6">
            Our support team is here to help. Feel free to reach out with any questions or concerns.
          </p>
          <a
            href="/contact"
            className="inline-block px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium"
          >
            Contact Us
          </a>
        </div>
      </section>

      <Footer />
    </div>
  )
}
