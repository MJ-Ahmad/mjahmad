import { Header } from '@/components/header'
import { Footer } from '@/components/footer'

export default function TermsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero */}
      <section className="py-12 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-foreground mb-2">Terms of Service</h1>
          <p className="text-foreground/70">Last updated: January 2025</p>
        </div>
      </section>

      {/* Content */}
      <section className="flex-1 py-16 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          {[
            {
              title: '1. Acceptance of Terms',
              content:
                'By accessing and using the AlQuranJourney website and services, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.',
            },
            {
              title: '2. Use License',
              content:
                'Permission is granted to temporarily download one copy of the materials (information or software) from AlQuranJourney for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not: modify or copy the materials; use the materials for any commercial purpose or for any public display; attempt to decompile or reverse engineer any software contained on the website; remove any copyright or other proprietary notations from the materials.',
            },
            {
              title: '3. Disclaimer',
              content:
                'The materials on AlQuranJourney\'s website are provided for informational purposes only. AlQuranJourney does not warrant the accuracy, completeness, or usefulness of this information. Any reliance you place on such information is strictly at your own risk.',
            },
            {
              title: '4. Donations',
              content:
                'By making a donation through our platform, you confirm that you are at least 18 years old or have parental consent, that you are the authorized user of the payment method, and that you authorize the charge to your account. All donations are non-refundable unless otherwise stated.',
            },
            {
              title: '5. Tax Deductibility',
              content:
                'AlQuranJourney is a registered non-profit organization. While donations may be tax-deductible, we recommend consulting with a tax professional regarding your specific circumstances. We are not responsible for tax implications of donations.',
            },
            {
              title: '6. Limitation of Liability',
              content:
                'In no event shall AlQuranJourney or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on the website, even if AlQuranJourney or an authorized representative has been notified of the possibility of such damage.',
            },
            {
              title: '7. Accuracy of Materials',
              content:
                'The materials appearing on AlQuranJourney\'s website could include technical, typographical, or photographic errors. AlQuranJourney does not warrant that any of the materials on the website are accurate, complete, or current. AlQuranJourney may make changes to the materials contained on the website at any time without notice.',
            },
            {
              title: '8. Links',
              content:
                'AlQuranJourney has not reviewed all of the sites linked to from the website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by AlQuranJourney of the site. Use of any such linked website is at the user\'s own risk.',
            },
            {
              title: '9. Modifications',
              content:
                'AlQuranJourney may revise these terms of service for the website at any time without notice. By using this website, you are agreeing to be bound by the then current version of these terms of service.',
            },
            {
              title: '10. Governing Law',
              content:
                'These terms and conditions are governed by and construed in accordance with the laws of the jurisdiction where AlQuranJourney is based, and you irrevocably submit to the exclusive jurisdiction of the courts in that location.',
            },
            {
              title: '11. User Conduct',
              content:
                'You agree not to use the website for any unlawful purpose or in any way that violates these terms. You further agree not to engage in any conduct that restricts or inhibits anyone\'s use or enjoyment of the website.',
            },
            {
              title: '12. Intellectual Property Rights',
              content:
                'All materials on the website, including text, graphics, logos, and images, are the property of AlQuranJourney or its content suppliers and are protected by international copyright laws. You may not reproduce or transmit any materials without our prior written consent.',
            },
            {
              title: '13. Contact Information',
              content:
                'If you have any questions about these Terms of Service or our practices, please contact us through our Contact page. We will respond to your inquiry within a reasonable timeframe.',
            },
          ].map((section, index) => (
            <div key={index}>
              <h2 className="text-2xl font-bold text-foreground mb-4">{section.title}</h2>
              <p className="text-foreground/70 leading-relaxed">{section.content}</p>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  )
}
