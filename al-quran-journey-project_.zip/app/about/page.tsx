'use client'

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import { Mail, Phone, MapPin, ExternalLink } from 'lucide-react'
import Link from 'next/link'

export default function About() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-primary/5 to-transparent">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl font-bold text-foreground mb-6">About Quraner Fariwala</h1>
          <p className="text-xl text-foreground/70 leading-relaxed">
            Bangladesh's largest Quran printing institution, serving over 5 million Hifz students 
            with mission-driven excellence and spiritual integrity.
          </p>
        </div>
      </section>

      {/* Organization Details */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Our Identity</h2>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="p-8">
              <h3 className="text-xl font-semibold text-primary mb-4">Legal Registration</h3>
              <ul className="space-y-3 text-foreground/70">
                <li><strong>UK Registration:</strong> Reg. 14066998</li>
                <li><strong>SIC Code:</strong> 85600 (Educational Support)</li>
                <li><strong>TRAD License:</strong> DSCC/03727/2021</li>
                <li><strong>Status:</strong> Mission-driven, operationally commercial</li>
              </ul>
            </Card>

            <Card className="p-8">
              <h3 className="text-xl font-semibold text-primary mb-4">Our Vision</h3>
              <div className="space-y-3 text-foreground/70">
                <p><strong>Heritage • Scholarship • Unity</strong></p>
                <ul className="list-disc list-inside space-y-2">
                  <li>Foster a national movement where every learner holds a Qur'an for deep memorization</li>
                  <li>Honor orphaned students and underserved Hifz centres with first priority</li>
                  <li>Elevate Bangladeshi editorial excellence and ethical stewardship</li>
                </ul>
              </div>
            </Card>
          </div>

          {/* Contact Information */}
          <div className="bg-secondary/50 rounded-lg p-8 mb-12">
            <h3 className="text-2xl font-bold text-foreground mb-8">Get In Touch</h3>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="flex gap-4">
                <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-foreground mb-2">Address</h4>
                  <p className="text-foreground/70">
                    27 Purana Paltan, Paltan<br />
                    Dhaka-1000, Bangladesh
                  </p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <Mail className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-foreground mb-2">Email</h4>
                  <Link href="mailto:quranerfariwala@gmail.com" className="text-primary hover:text-accent transition-colors">
                    quranerfariwala@gmail.com
                  </Link>
                </div>
              </div>
              
              <div className="flex gap-4">
                <Phone className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-semibold text-foreground mb-2">Phone</h4>
                  <Link href="tel:+88017888556628" className="text-primary hover:text-accent transition-colors">
                    +880-1788856628
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-foreground mb-8">Donation & Payment Methods</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="p-6">
                <h4 className="font-semibold text-foreground mb-4">Bangladesh Bank Accounts</h4>
                <ul className="space-y-3 text-sm text-foreground/70">
                  <li><strong>bKash Merchant:</strong> 01788856628</li>
                  <li><strong>City Bank:</strong> A/C 1502835465001</li>
                  <li><strong>Brac Bank:</strong> A/C 2060133490001</li>
                  <li><strong>Eastern Bank Ltd:</strong> A/C 1011070611663</li>
                  <li><strong>Mutual Trust Bank:</strong> A/C 1301010000896</li>
                </ul>
              </Card>

              <Card className="p-6">
                <h4 className="font-semibold text-foreground mb-4">International Methods</h4>
                <ul className="space-y-3 text-sm text-foreground/70">
                  <li><strong>MetaMask Address:</strong></li>
                  <p className="font-mono text-xs bg-secondary p-2 rounded mb-4 break-all">
                    0xaD6fE115967c22D1C54Fe6010C3AacCE5E196435
                  </p>
                  <li className="text-foreground">Coming Soon: Ko-fi, Stripe, multi-currency gateway</li>
                </ul>
              </Card>
            </div>
          </div>

          {/* Social Links */}
          <div className="bg-primary/5 rounded-lg p-8">
            <h3 className="text-xl font-semibold text-foreground mb-6">Connect With Us</h3>
            <div className="flex flex-wrap gap-4">
              <Link href="https://web.facebook.com/quranerfariwala037271" target="_blank" 
                className="inline-flex items-center gap-2 text-primary hover:text-accent transition-colors">
                <ExternalLink className="w-4 h-4" />
                Facebook
              </Link>
              <Link href="https://linkedin.com/in/jafor-ahmad" target="_blank"
                className="inline-flex items-center gap-2 text-primary hover:text-accent transition-colors">
                <ExternalLink className="w-4 h-4" />
                LinkedIn
              </Link>
              <Link href="https://github.com/MJ-Ahmad" target="_blank"
                className="inline-flex items-center gap-2 text-primary hover:text-accent transition-colors">
                <ExternalLink className="w-4 h-4" />
                GitHub
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
