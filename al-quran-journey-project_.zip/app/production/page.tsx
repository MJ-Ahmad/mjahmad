import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { Check, Zap, Shield, Award, TrendingUp, Target } from 'lucide-react'
import Image from 'next/image'

const productionSteps = [
  {
    number: 1,
    title: 'Manuscript Authentication',
    description:
      'We begin with the most critical step—authenticating manuscripts from verified scholarly sources. Every text undergoes cross-verification with international Islamic institutions and academic references.',
    details: [
      'Quranic authenticity certification',
      'Scholarly cross-verification',
      'Linguistic accuracy audits',
    ],
  },
  {
    number: 2,
    title: 'Design & Typesetting Excellence',
    description:
      'Our design team creates memorization-optimized layouts using professional typography that balances traditional beauty with modern readability. Each page is carefully crafted for learning.',
    details: [
      'Memorization-optimized layout',
      'Professional Arabic typesetting',
      'Perfect page proportions',
    ],
  },
  {
    number: 3,
    title: 'Advanced Proof Review',
    description:
      'Multi-stage proofreading ensures zero errors. Our team reviews every page against source manuscripts using technology and human expertise combined.',
    details: [
      'Digital scanning verification',
      'Human expert proofreading',
      'Content accuracy certification',
    ],
  },
  {
    number: 4,
    title: 'High-Tech Precision Printing',
    description:
      'State-of-the-art printing machinery produces copies with exceptional color accuracy, clarity, and durability. We use premium eco-friendly materials without compromising quality.',
    details: [
      'CMYK color precision',
      'High-resolution output',
      'Sustainable paper stock',
    ],
  },
  {
    number: 5,
    title: 'Professional Binding & Finishing',
    description:
      'Expert binding ensures durability for decades of use. Each book is crafted with respect for the sacred text, featuring protective covers and elegant finishing.',
    details: [
      'Durable bookbinding',
      'Protective coverings',
      'Premium finishing details',
    ],
  },
  {
    number: 6,
    title: 'Quality Verification & Distribution',
    description:
      'Final inspection, cataloging, and secure packaging prepare each Quran for its journey to students worldwide. Every copy is tracked and verified before dispatch.',
    details: [
      'Final quality checkpoints',
      'Secure packaging protocol',
      'Distribution coordination',
    ],
  },
]

const qualityStandards = [
  {
    icon: Shield,
    title: 'ISO Certified Excellence',
    description: 'International quality management standards applied across all production stages',
  },
  {
    icon: Target,
    title: 'Zero-Defect Commitment',
    description: 'Every copy undergoes 15+ quality checkpoints before reaching students',
  },
  {
    icon: Zap,
    title: 'Advanced Technology',
    description: 'State-of-the-art machinery ensures precision, consistency, and durability',
  },
  {
    icon: TrendingUp,
    title: 'Continuous Improvement',
    description: 'Regular audits and technology upgrades keep us at industry forefront',
  },
  {
    icon: Award,
    title: 'Heritage & Innovation',
    description: 'Blending traditional Quranic principles with modern best practices',
  },
  {
    icon: Check,
    title: 'Sustainability Focus',
    description: 'Eco-friendly materials and processes minimize environmental impact',
  },
]

export default function ProductionPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section with Background */}
      <section className="relative h-[600px] sm:h-[700px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/images/printing-facility.jpg"
            alt="Production Facility"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/85 to-background/75"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto text-center px-4">
          <div className="inline-block mb-6 px-4 py-2 bg-accent/20 rounded-full border border-accent/50 backdrop-blur-sm">
            <p className="text-sm font-semibold text-accent">Production Excellence</p>
          </div>
          <h1 className="text-6xl sm:text-7xl lg:text-8xl font-bold text-foreground mb-6 leading-tight text-balance">
            Excellence in Every{' '}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Step
            </span>
          </h1>
          <p className="text-lg sm:text-xl text-foreground/90 mb-8 max-w-2xl mx-auto leading-relaxed">
            A 6-step journey of precision, technology, and dedication. From authenticated manuscripts 
            to students' hands, we ensure every Quran meets our uncompromising standards of excellence.
          </p>
          <Button
            asChild
            size="lg"
            className="bg-accent text-foreground hover:bg-accent/90 font-semibold"
          >
            <Link href="/donate">Support Production</Link>
          </Button>
        </div>
      </section>

      {/* Production Process Timeline */}
      <section className="py-24 px-4 bg-gradient-to-b from-secondary/30 to-background">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-bold text-foreground mb-4 text-balance">
              Our 6-Step Production Journey
            </h2>
            <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
              Every Quran is a testament to our commitment to perfection and respect for the sacred text.
            </p>
          </div>

          <div className="space-y-12">
            {productionSteps.map((step, index) => (
              <div key={step.number} className="group relative">
                {/* Timeline Connector */}
                {index < productionSteps.length - 1 && (
                  <div className="absolute left-14 sm:left-20 top-32 w-1 h-24 bg-gradient-to-b from-primary to-accent/30"></div>
                )}

                <div className="grid sm:grid-cols-[160px_1fr] gap-8 items-start">
                  {/* Step Number */}
                  <div className="flex items-start justify-center pt-2">
                    <div className="relative">
                      <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary/25 to-accent/25 flex items-center justify-center border-3 border-primary/40 group-hover:border-primary/80 transition-all shadow-xl">
                        <span className="text-6xl font-black text-transparent bg-gradient-to-br from-primary to-accent bg-clip-text">
                          {step.number}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Step Details */}
                  <div className="p-10 bg-background rounded-2xl border border-border group-hover:border-primary/50 transition-all group-hover:shadow-xl group-hover:-translate-y-1">
                    <div className="flex items-start gap-4 mb-4">
                      <Award className="w-8 h-8 text-accent mt-1 flex-shrink-0" />
                      <h3 className="text-3xl font-bold text-foreground">{step.title}</h3>
                    </div>
                    <p className="text-lg text-foreground/75 mb-8 leading-relaxed">{step.description}</p>
                    <div className="grid sm:grid-cols-3 gap-4">
                      {step.details.map((detail, i) => (
                        <div key={i} className="flex items-start gap-3 p-4 bg-primary/5 rounded-xl hover:bg-primary/10 transition-all border border-primary/10">
                          <Zap className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                          <span className="text-sm font-semibold text-foreground/85">{detail}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quality Standards Grid */}
      <section className="py-24 px-4 bg-background">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-foreground mb-4 text-balance">Quality Assurance Standards</h2>
            <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
              Six pillars of excellence ensuring every Quran meets international standards
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {qualityStandards.map((standard, index) => {
              const Icon = standard.icon
              return (
                <div
                  key={index}
                  className="group p-8 bg-gradient-to-br from-background to-secondary/30 rounded-xl border border-border hover:border-primary/50 hover:shadow-lg transition-all hover:-translate-y-1"
                >
                  <div className="flex items-start gap-4 mb-6">
                    <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-3">{standard.title}</h3>
                  <p className="text-foreground/70 leading-relaxed">{standard.description}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Production Image Section */}
      <section className="py-24 px-4 bg-gradient-to-b from-secondary/30 to-background">
        <div className="max-w-7xl mx-auto">
          <div className="relative h-96 sm:h-[500px] rounded-2xl overflow-hidden border-4 border-primary/30 shadow-2xl group">
            <Image
              src="/images/quality-control.jpg"
              alt="Quality Control Process"
              fill
              className="object-cover group-hover:scale-110 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/40 via-transparent to-transparent flex items-end p-8 sm:p-12">
              <div className="max-w-2xl">
                <h3 className="text-3xl sm:text-4xl font-bold text-foreground mb-3">Precision Inspection</h3>
                <p className="text-lg text-foreground/90">
                  Our quality control experts perform meticulous inspections at every stage, ensuring 
                  each Quran meets our exacting standards before it reaches students worldwide.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-24 px-4 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5">
        <div className="max-w-7xl mx-auto">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: TrendingUp, stat: '170K+', label: 'Qurans Produced', desc: 'In recent years' },
              { icon: Target, stat: '100%', label: 'Quality Verified', desc: 'Every copy checked' },
              { icon: Award, stat: '15+', label: 'Years Experience', desc: 'Excellence legacy' },
              { icon: Check, stat: '0', label: 'Defect Rate', desc: 'Zero tolerance' },
            ].map((item, index) => {
              const Icon = item.icon
              return (
                <div key={index} className="text-center p-8 rounded-xl bg-background/50 border border-primary/20 hover:border-primary/50 hover:bg-background transition-all">
                  <Icon className="w-12 h-12 text-primary mx-auto mb-4" />
                  <div className="text-4xl font-black bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
                    {item.stat}
                  </div>
                  <p className="font-semibold text-foreground mb-1">{item.label}</p>
                  <p className="text-sm text-foreground/70">{item.desc}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4 bg-gradient-to-r from-primary via-primary/90 to-accent text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-5xl font-bold mb-6 text-balance">Support Quality Production</h2>
          <p className="text-xl text-primary-foreground/90 mb-12 leading-relaxed max-w-2xl mx-auto">
            Help us continue producing exceptional Qurans using cutting-edge technology and 
            traditional excellence. Every donation directly supports our mission.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-accent text-foreground hover:bg-accent/90 font-semibold text-lg"
            >
              <Link href="/donate">Donate Now</Link>
            </Button>
            <Button
              asChild
              size="lg"
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 font-semibold text-lg"
            >
              <Link href="/sponsorship-tracker">View Impact</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
