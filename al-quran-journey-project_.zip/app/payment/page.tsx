'use client'

import React from "react"

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { useDonation } from '@/lib/donation-context'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { CreditCard, Lock, ChevronRight } from 'lucide-react'

export default function PaymentPage() {
  const { items, getTotalAmount, clearCart } = useDonation()
  const router = useRouter()
  const [cardData, setCardData] = useState({
    cardName: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
  })
  const [processing, setProcessing] = useState(false)
  const total = getTotalAmount()

  const handleCardChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let { name, value } = e.target

    // Format card number
    if (name === 'cardNumber') {
      value = value.replace(/\s/g, '').replace(/(\d{4})/g, '$1 ').trim()
    }

    // Format expiry date
    if (name === 'expiryDate') {
      value = value.replace(/\D/g, '')
      if (value.length >= 2) {
        value = value.slice(0, 2) + '/' + value.slice(2, 4)
      }
    }

    // Format CVV
    if (name === 'cvv') {
      value = value.replace(/\D/g, '').slice(0, 4)
    }

    setCardData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setProcessing(true)

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Clear cart and redirect to thank you page
    clearCart()
    router.push('/thank-you')
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <div className="flex-1 flex items-center justify-center px-4">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-foreground mb-4">Your cart is empty</h1>
            <Button asChild className="bg-primary text-primary-foreground">
              <Link href="/donate">Back to Donations</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Progress */}
      <div className="border-b border-border bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <Link href="/cart" className="text-foreground/70 hover:text-foreground">
              Cart
            </Link>
            <ChevronRight className="w-4 h-4 text-foreground/50" />
            <Link href="/checkout" className="text-foreground/70 hover:text-foreground">
              Checkout
            </Link>
            <ChevronRight className="w-4 h-4 text-foreground/50" />
            <span className="text-primary font-semibold">Payment</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <section className="flex-1 py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Payment Form */}
            <div className="lg:col-span-2">
              <h1 className="text-3xl font-bold text-foreground mb-8">Payment Method</h1>

              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Payment Method Selection */}
                <div>
                  <h2 className="text-xl font-semibold text-foreground mb-4">Select Payment Method</h2>
                  <div className="space-y-3">
                    <label className="flex items-center p-4 border-2 border-primary rounded-lg cursor-pointer bg-primary/5">
                      <input type="radio" name="method" value="card" defaultChecked className="w-4 h-4" />
                      <CreditCard className="w-5 h-5 ml-3 text-primary" />
                      <span className="ml-3 font-medium text-foreground">Credit/Debit Card</span>
                    </label>
                  </div>
                </div>

                {/* Card Details */}
                <div className="space-y-4">
                  <h2 className="text-xl font-semibold text-foreground">Card Details</h2>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Cardholder Name
                    </label>
                    <input
                      type="text"
                      name="cardName"
                      required
                      value={cardData.cardName}
                      onChange={handleCardChange}
                      className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="John Doe"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Card Number
                    </label>
                    <input
                      type="text"
                      name="cardNumber"
                      required
                      maxLength={19}
                      value={cardData.cardNumber}
                      onChange={handleCardChange}
                      className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-mono"
                      placeholder="4242 4242 4242 4242"
                    />
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Expiry Date
                      </label>
                      <input
                        type="text"
                        name="expiryDate"
                        required
                        maxLength={5}
                        value={cardData.expiryDate}
                        onChange={handleCardChange}
                        className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-mono"
                        placeholder="MM/YY"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">CVV</label>
                      <input
                        type="text"
                        name="cvv"
                        required
                        maxLength={4}
                        value={cardData.cvv}
                        onChange={handleCardChange}
                        className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-mono"
                        placeholder="123"
                      />
                    </div>
                  </div>
                </div>

                {/* Security Notice */}
                <div className="flex items-start gap-3 p-4 bg-accent/10 rounded-lg border border-accent/20">
                  <Lock className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-foreground/70">
                    <p className="font-medium text-foreground mb-1">Your donation is secure</p>
                    <p>
                      We use industry-standard SSL encryption to protect your payment information. Your
                      data is never stored on our servers.
                    </p>
                  </div>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={processing}
                  size="lg"
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
                >
                  {processing ? 'Processing...' : `Complete Donation - $${total.toFixed(2)}`}
                </Button>

                {/* Disclaimer */}
                <p className="text-xs text-foreground/60 text-center">
                  For testing purposes, use card number: 4242 4242 4242 4242 with any future date and
                  any 3-digit CVV
                </p>
              </form>
            </div>

            {/* Summary */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 p-6 bg-secondary/30 border border-border rounded-lg">
                <h3 className="text-xl font-bold text-foreground mb-6">Donation Summary</h3>

                <div className="space-y-3 mb-6 pb-6 border-b border-border">
                  {items.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span className="text-foreground/70">
                        {item.name} x {item.quantity}
                      </span>
                      <span className="font-semibold text-foreground">
                        ${(item.amount * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-foreground/70">Subtotal</span>
                    <span className="font-semibold text-foreground">${total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-foreground/60">
                    <span>Processing fee</span>
                    <span>$0.00</span>
                  </div>
                  <div className="border-t border-border pt-4 mt-4 flex justify-between">
                    <span className="font-bold text-foreground">Total Amount</span>
                    <span className="text-2xl font-bold text-primary">${total.toFixed(2)}</span>
                  </div>
                </div>

                <div className="p-4 bg-primary/5 rounded border border-primary/20">
                  <h4 className="font-semibold text-foreground text-sm mb-2">Your Impact</h4>
                  <ul className="text-xs text-foreground/70 space-y-1">
                    {items.map((item) => (
                      <li key={item.id}>{item.impact}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
