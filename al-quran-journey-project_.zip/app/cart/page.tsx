'use client'

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { useDonation } from '@/lib/donation-context'
import { Trash2, Plus, Minus, ShoppingCart } from 'lucide-react'

export default function CartPage() {
  const { items, removeItem, updateQuantity, getTotalAmount } = useDonation()
  const total = getTotalAmount()

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-12 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">Donation Cart</h1>
          <p className="text-foreground/70">Review your donations before checkout</p>
        </div>
      </section>

      {/* Main Content */}
      <section className="flex-1 py-16 px-4">
        <div className="max-w-7xl mx-auto">
          {items.length === 0 ? (
            // Empty Cart
            <div className="text-center py-12">
              <ShoppingCart className="w-16 h-16 mx-auto text-foreground/30 mb-4" />
              <h2 className="text-2xl font-bold text-foreground mb-4">Your cart is empty</h2>
              <p className="text-foreground/70 mb-8">
                Start making a difference by selecting a donation option.
              </p>
              <Button
                asChild
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Link href="/donate">Browse Donations</Link>
              </Button>
            </div>
          ) : (
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2 space-y-4">
                <h2 className="text-2xl font-bold text-foreground mb-6">Donation Items</h2>
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="flex gap-4 p-6 bg-background border border-border rounded-lg hover:border-primary/30 transition-colors"
                  >
                    {/* Item Info */}
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground text-lg">{item.name}</h3>
                      <p className="text-foreground/70 text-sm mb-2">{item.description}</p>
                      <p className="text-sm text-accent font-medium">{item.impact}</p>
                    </div>

                    {/* Price & Quantity */}
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary mb-4">${item.amount}</div>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-2 bg-secondary rounded-lg p-2 mb-4 w-fit ml-auto">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-muted rounded text-foreground"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="w-8 text-center font-semibold text-foreground">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-muted rounded text-foreground"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Subtotal */}
                      <div className="text-lg font-semibold text-foreground mb-3">
                        ${(item.amount * item.quantity).toFixed(2)}
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => removeItem(item.id)}
                        className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Summary */}
              <div className="lg:col-span-1">
                <div className="sticky top-24 p-6 bg-secondary/30 border border-border rounded-lg">
                  <h3 className="text-xl font-bold text-foreground mb-6">Order Summary</h3>

                  {/* Line Items */}
                  <div className="space-y-3 mb-6 pb-6 border-b border-border">
                    {items.map((item) => (
                      <div key={item.id} className="flex justify-between text-sm">
                        <span className="text-foreground/70">
                          {item.name} x {item.quantity}
                        </span>
                        <span className="font-semibold text-foreground">
                          ${(item.amount * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Total */}
                  <div className="mb-6">
                    <div className="flex justify-between items-baseline mb-2">
                      <span className="text-foreground/70">Subtotal</span>
                      <span className="text-lg font-semibold text-foreground">${total.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-baseline text-sm text-foreground/60">
                      <span>Processing fee</span>
                      <span>$0.00</span>
                    </div>
                    <div className="border-t border-border pt-4 mt-4 flex justify-between items-baseline">
                      <span className="text-lg font-bold text-foreground">Total</span>
                      <span className="text-2xl font-bold text-primary">${total.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Checkout Button */}
                  <Button
                    asChild
                    size="lg"
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90 mb-3"
                  >
                    <Link href="/checkout">Proceed to Checkout</Link>
                  </Button>

                  {/* Continue Shopping */}
                  <Button
                    asChild
                    variant="outline"
                    className="w-full border-primary text-primary bg-transparent"
                  >
                    <Link href="/donate">Continue Shopping</Link>
                  </Button>

                  {/* Info */}
                  <div className="mt-6 p-4 bg-accent/10 rounded border border-accent/20">
                    <p className="text-xs text-foreground/70">
                      Your donation is secure and will be processed safely. We protect your
                      information with industry-standard encryption.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  )
}
