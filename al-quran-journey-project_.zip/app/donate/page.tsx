'use client'

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { useDonation } from '@/lib/donation-context'
import { useState } from 'react'
import { ShoppingCart, Heart, Zap, Globe, Users } from 'lucide-react'
import Image from 'next/image'

const donationOptions = [
  {
    id: 'single-copy',
    name: 'Single Copy Sponsor',
    description: 'Sponsor one memorization-optimized Quran for a deserving student',
    amount: 3.25,
    currency: 'USD',
    localAmount: '350 BDT',
    impact: 'Provides 1 beautifully printed Quran to an orphan or underserved learner',
  },
  {
    id: 'batch-sponsor',
    name: 'Batch Sponsor (1,000 Copies)',
    description: 'Sponsor 1,000 Qurans for institutional distribution',
    amount: 2200,
    currency: 'USD',
    localAmount: '242,920 BDT',
    impact: 'Distributes 1,000 memorization-optimized Qurans across schools and Hifz centres',
  },
  {
    id: 'debt-recovery',
    name: 'Debt Recovery Partner',
    description: 'Support institutional healing and legacy debt settlement',
    amount: 22500,
    currency: 'USD',
    localAmount: 'Flexible',
    impact: 'Restores institutional sustainability and secures long-term operations',
  },
  {
    id: 'infrastructure',
    name: 'Infrastructure Patron',
    description: 'Sponsor team rebuilding, technology, and logistics',
    amount: 16000,
    currency: 'USD',
    localAmount: 'Flexible',
    impact: 'Strengthens production capacity, team capability, and distribution network',
  },
  {
    id: 'campaign-ally',
    name: 'Global Campaign Ally',
    description: 'Fund outreach, media production, and donor engagement',
    amount: 11000,
    currency: 'USD',
    localAmount: 'Flexible',
    impact: 'Amplifies campaign reach across 6+ currencies and global communities',
  },
  {
    id: 'custom',
    name: 'Custom Donation',
    description: 'Choose your own amount to support Quraner Fariwala',
    amount: 0,
    impact: 'Your custom donation makes a difference',
  },
]

export default function DonatePage() {
  const { addItem } = useDonation()
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null)
  const [customAmount, setCustomAmount] = useState('')

  const handleDonate = (option: (typeof donationOptions)[0]) => {
    const amount = option.id === 'custom' ? Number(customAmount) : option.amount
    if (amount <= 0) return

    addItem({
      id: option.id,
      name: option.name,
      description: option.description,
      amount: amount,
      quantity: 1,
      impact: option.impact,
    })
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative h-[550px] sm:h-[650px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/images/hifz-students.jpg"
            alt="Hifz Students"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/85 to-background/75"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto text-center px-4">
          <div className="inline-block mb-6 px-4 py-2 bg-accent/20 rounded-full border border-accent/50 backdrop-blur-sm">
            <p className="text-sm font-semibold text-accent">Ramadhan-2026 Campaign</p>
          </div>
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight text-balance">
            Transform Lives Through{' '}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Giving
            </span>
          </h1>
          <p className="text-lg sm:text-xl text-foreground/90 mb-8 max-w-2xl mx-auto leading-relaxed">
            Join our mission to print and distribute 40,000 memorization-optimized Qurans. Your donation 
            empowers orphans and underserved Hifz students across Bangladesh and South Asia.
          </p>
        </div>
      </section>

      {/* Donation Options */}
      <section className="py-20 px-4 flex-1">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">Ways to Support Us</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {donationOptions.map((option) => (
              <div
                key={option.id}
                className="p-6 border border-border rounded-lg hover:border-primary/30 transition-all"
              >
                <h3 className="text-xl font-semibold text-foreground mb-2">{option.name}</h3>
                <p className="text-foreground/70 text-sm mb-4">{option.description}</p>

                {/* Impact */}
                <div className="bg-accent/10 border border-accent/20 rounded p-3 mb-4">
                  <p className="text-sm text-foreground">
                    <span className="font-semibold">Impact:</span> {option.impact}
                  </p>
                </div>

                {/* Amount */}
                {option.id !== 'custom' ? (
                  <div className="mb-4">
                    <p className="text-3xl font-bold text-primary mb-4">${option.amount}</p>
                    <Button
                      onClick={() => handleDonate(option)}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                    >
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Add to Cart
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <input
                      type="number"
                      min="1"
                      placeholder="Enter amount ($)"
                      value={customAmount}
                      onChange={(e) => setCustomAmount(e.target.value)}
                      className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <Button
                      onClick={() => handleDonate(option)}
                      disabled={!customAmount || Number(customAmount) <= 0}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
                    >
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Add to Cart
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Donate Section */}
      <section className="py-20 px-4 bg-secondary/30">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">Why Your Donation Matters</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: 'Direct Impact',
                description:
                  'Your donation directly supports the printing and distribution of the Holy Quran to communities worldwide.',
              },
              {
                title: 'Research Support',
                description:
                  'Contribute to scholarly research that deepens understanding and appreciation of the Quranic text.',
              },
              {
                title: 'Community Building',
                description:
                  'Help us strengthen communities through education, outreach, and spiritual development programs.',
              },
              {
                title: 'Global Reach',
                description:
                  'Expand our distribution network to reach underserved communities across multiple continents.',
              },
            ].map((item, index) => (
              <div key={index} className="p-6 bg-background rounded-lg border border-border">
                <h3 className="text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-foreground/70">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA to Cart */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center bg-primary/5 border border-primary/20 rounded-lg p-8">
          <h2 className="text-2xl font-bold text-foreground mb-4">Ready to Donate?</h2>
          <p className="text-foreground/70 mb-6">
            Review your selections and proceed to checkout to complete your donation.
          </p>
          <Button
            asChild
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Link href="/cart">
              <ShoppingCart className="w-5 h-5 mr-2" />
              Review Cart
            </Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
