'use client'

import React from "react"

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Mail, Phone, MapPin } from 'lucide-react'
import { useState } from 'react'

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  })

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log('Form submitted:', formData)
    setFormData({ name: '', email: '', subject: '', message: '' })
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero */}
      <section className="py-16 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-4">Get in Touch</h1>
          <p className="text-lg text-foreground/70">
            We'd love to hear from you. Whether you have a question about our mission, need
            assistance, or want to get involved, we're here to help.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="flex-1 py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {/* Contact Info */}
            {[
              {
                icon: Mail,
                title: 'Email',
                content: 'support@alquranjourney.org',
                details: 'We respond within 24-48 hours',
              },
              {
                icon: Phone,
                title: 'Phone',
                content: '+1 (555) 123-4567',
                details: 'Monday - Friday, 9AM - 5PM',
              },
              {
                icon: MapPin,
                title: 'Address',
                content: '123 Spiritual Way, Holy City, HC 12345',
                details: 'Headquarters & Main Office',
              },
            ].map((item, index) => {
              const Icon = item.icon
              return (
                <div key={index} className="p-6 bg-background border border-border rounded-lg">
                  <Icon className="w-8 h-8 text-primary mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-foreground font-medium mb-1">{item.content}</p>
                  <p className="text-sm text-foreground/70">{item.details}</p>
                </div>
              )
            })}
          </div>

          {/* Contact Form */}
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Form */}
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-6">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Name</label>
                  <input
                    type="text"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="your@email.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Subject</label>
                  <select
                    name="subject"
                    required
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="">Select a subject</option>
                    <option value="donation">Donation Inquiry</option>
                    <option value="general">General Question</option>
                    <option value="research">Research Collaboration</option>
                    <option value="distribution">Distribution Partnership</option>
                    <option value="feedback">Feedback</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Message</label>
                  <textarea
                    name="message"
                    required
                    rows={6}
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                    placeholder="Your message..."
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium"
                >
                  Send Message
                </button>
              </form>
            </div>

            {/* Info */}
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-bold text-foreground mb-3">Why Contact Us?</h3>
                <ul className="space-y-3 text-foreground/70">
                  <li className="flex gap-3">
                    <span className="w-2 h-2 rounded-full bg-accent mt-1.5 flex-shrink-0"></span>
                    <span>Ask questions about our mission and work</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="w-2 h-2 rounded-full bg-accent mt-1.5 flex-shrink-0"></span>
                    <span>Get assistance with donations</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="w-2 h-2 rounded-full bg-accent mt-1.5 flex-shrink-0"></span>
                    <span>Explore partnership opportunities</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="w-2 h-2 rounded-full bg-accent mt-1.5 flex-shrink-0"></span>
                    <span>Share feedback and suggestions</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="w-2 h-2 rounded-full bg-accent mt-1.5 flex-shrink-0"></span>
                    <span>Report issues or concerns</span>
                  </li>
                </ul>
              </div>

              <div className="bg-accent/10 border border-accent/30 rounded-lg p-6">
                <h3 className="font-semibold text-foreground mb-2">Response Time</h3>
                <p className="text-sm text-foreground/70">
                  We aim to respond to all inquiries within 24-48 hours during business days. For
                  urgent matters, please call us directly.
                </p>
              </div>

              <div className="bg-secondary/30 border border-border rounded-lg p-6">
                <h3 className="font-semibold text-foreground mb-3">Departments</h3>
                <div className="space-y-2 text-sm text-foreground/70">
                  <p>
                    <span className="font-medium text-foreground">General Support:</span> Monday-Friday
                    9AM-5PM
                  </p>
                  <p>
                    <span className="font-medium text-foreground">Donations:</span> Any time (online
                    form)
                  </p>
                  <p>
                    <span className="font-medium text-foreground">Research:</span> By appointment
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
