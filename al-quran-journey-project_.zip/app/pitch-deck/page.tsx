'use client'

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Globe, Users, BookOpen, TrendingUp, Target, Award } from 'lucide-react'
import Link from 'next/link'

export default function PitchDeck() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Campaign Hero */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 via-accent/5 to-primary/10">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-block mb-4 px-4 py-2 bg-accent/20 rounded-full border border-accent/50">
            <p className="text-sm font-semibold text-accent">📜 Global Revival Campaign</p>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">
            Ramadhan-2026: Global Revival of Qur'anic Access
          </h1>
          <p className="text-xl text-foreground/70 mb-8 max-w-3xl mx-auto">
            Imagine a classroom bathed in morning sunlight, where young voices rise in soulful recitation. 
            Each page becomes a beacon of heritage, healing, and hope—illuminating hearts across Bangladesh and beyond.
          </p>
          <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Link href="/donate">Support This Campaign</Link>
          </Button>
        </div>
      </section>

      {/* Campaign Vision */}
      <section className="py-20 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-foreground mb-4 text-center">Expanded Vision: Restoration, Dignity, Global Solidarity</h2>
          <p className="text-center text-foreground/70 mb-12 max-w-2xl mx-auto">Our four-pillar mission for 2026</p>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 border-l-4 border-l-primary">
              <h3 className="text-xl font-semibold text-foreground mb-3 flex items-center gap-2">
                <Globe className="w-5 h-5 text-primary" />
                Rebuild Bangladesh's Legacy
              </h3>
              <p className="text-foreground/70">
                Strengthen Bangladesh's leading Qur'an printing institution after years of financial hardship, 
                ensuring decades of sustainable impact.
              </p>
            </Card>

            <Card className="p-8 border-l-4 border-l-accent">
              <h3 className="text-xl font-semibold text-foreground mb-3 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-accent" />
                Print 40,000 Qur'ans
              </h3>
              <p className="text-foreground/70">
                Launch a global campaign to print and distribute 40,000 memorization-optimized Qur'ans 
                by January 2026.
              </p>
            </Card>

            <Card className="p-8 border-l-4 border-l-primary">
              <h3 className="text-xl font-semibold text-foreground mb-3 flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                Prioritize the Underserved
              </h3>
              <p className="text-foreground/70">
                Place orphaned learners and underserved Hifz centres across South Asia at the center 
                of our distribution.
              </p>
            </Card>

            <Card className="p-8 border-l-4 border-l-accent">
              <h3 className="text-xl font-semibold text-foreground mb-3 flex items-center gap-2">
                <Globe className="w-5 h-5 text-accent" />
                Global Solidarity
              </h3>
              <p className="text-foreground/70">
                Invite international patrons to sponsor, partner, and uplift this sacred legacy 
                across continents.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Program Scope */}
      <section className="py-20 px-4 bg-secondary/30">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-foreground mb-12 text-center">Program Scope</h2>
          
          <div className="space-y-6">
            {[
              {
                icon: BookOpen,
                title: '40,000 Qur\'an Majeed Volumes',
                description: 'Tailored for memorization and classroom use with optimal layout and design'
              },
              {
                icon: TrendingUp,
                title: 'Institutional Infrastructure',
                description: 'Restore capacity, settle legacy debts, and ensure long-term sustainability'
              },
              {
                icon: Globe,
                title: 'Multi-Currency Gateway',
                description: 'Accept donations in USD, GBP, EUR, CAD, AUD, SAR, and BDT'
              },
              {
                icon: Users,
                title: 'Diaspora Engagement',
                description: 'Enable global Muslim communities to contribute with pride and transparency'
              }
            ].map((item, index) => {
              const Icon = item.icon
              return (
                <Card key={index} className="p-6 flex gap-4">
                  <Icon className="w-8 h-8 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                    <p className="text-foreground/70">{item.description}</p>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Product Specifications */}
      <section className="py-20 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-foreground mb-12 text-center">Product Excellence</h2>
          
          <Card className="p-8 bg-gradient-to-br from-primary/5 to-accent/5 border-2 border-primary/20">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-4">Specifications</h3>
                <ul className="space-y-3 text-foreground/70">
                  <li><strong>Size:</strong> 21 cm × 14 cm</li>
                  <li><strong>Pages:</strong> 668 pages</li>
                  <li><strong>Paper:</strong> 61 GSM archival-grade</li>
                  <li><strong>Printing:</strong> 4-colour offset</li>
                  <li><strong>Binding:</strong> Durable cover + protective slipcase</li>
                  <li><strong>Layout:</strong> Symbolic markers for Hifz optimization</li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-4">Quality Commitment</h3>
                <ul className="space-y-3 text-foreground/70">
                  <li>✓ Archival-grade materials for long-term preservation</li>
                  <li>✓ High-contrast, easy-to-read typography</li>
                  <li>✓ Optimal page layout for memorization</li>
                  <li>✓ Beautiful, durable binding</li>
                  <li>✓ Protective packaging for safe delivery</li>
                  <li>✓ Ethical printing standards</li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Budget Breakdown */}
      <section className="py-20 px-4 bg-secondary/30">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-foreground mb-12 text-center">Budget Snapshot</h2>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-primary">
                  <th className="text-left py-4 px-4 text-foreground font-semibold">Item</th>
                  <th className="text-right py-4 px-4 text-foreground font-semibold">BDT</th>
                  <th className="text-right py-4 px-4 text-foreground font-semibold">USD</th>
                  <th className="text-right py-4 px-4 text-foreground font-semibold">GBP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                <tr className="hover:bg-primary/5 transition-colors">
                  <td className="py-4 px-4 text-foreground">Qur'an Printing (40,000 copies)</td>
                  <td className="text-right py-4 px-4 text-foreground/70">9,716,800</td>
                  <td className="text-right py-4 px-4 text-foreground/70">$88,000</td>
                  <td className="text-right py-4 px-4 text-foreground/70">£72,000</td>
                </tr>
                <tr className="hover:bg-primary/5 transition-colors">
                  <td className="py-4 px-4 text-foreground">Operational, Legal & Contingency</td>
                  <td className="text-right py-4 px-4 text-foreground/70">1,000,000</td>
                  <td className="text-right py-4 px-4 text-foreground/70">$9,000</td>
                  <td className="text-right py-4 px-4 text-foreground/70">£7,500</td>
                </tr>
                <tr className="hover:bg-primary/5 transition-colors">
                  <td className="py-4 px-4 text-foreground">Institutional Debt Recovery (2 years)</td>
                  <td className="text-right py-4 px-4 text-foreground/70">2,500,000</td>
                  <td className="text-right py-4 px-4 text-foreground/70">$22,500</td>
                  <td className="text-right py-4 px-4 text-foreground/70">£18,500</td>
                </tr>
                <tr className="hover:bg-primary/5 transition-colors">
                  <td className="py-4 px-4 text-foreground">Infrastructure & Team Restoration</td>
                  <td className="text-right py-4 px-4 text-foreground/70">1,800,000</td>
                  <td className="text-right py-4 px-4 text-foreground/70">$16,000</td>
                  <td className="text-right py-4 px-4 text-foreground/70">£13,000</td>
                </tr>
                <tr className="hover:bg-primary/5 transition-colors">
                  <td className="py-4 px-4 text-foreground">Global Outreach, Tech & Fundraising</td>
                  <td className="text-right py-4 px-4 text-foreground/70">1,200,000</td>
                  <td className="text-right py-4 px-4 text-foreground/70">$11,000</td>
                  <td className="text-right py-4 px-4 text-foreground/70">£9,000</td>
                </tr>
                <tr className="bg-primary/10 border-t-2 border-primary">
                  <td className="py-4 px-4 font-semibold text-foreground">Total Required</td>
                  <td className="text-right py-4 px-4 font-semibold text-foreground">16,216,800</td>
                  <td className="text-right py-4 px-4 font-semibold text-foreground">$146,500</td>
                  <td className="text-right py-4 px-4 font-semibold text-foreground">£120,000</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Impact Metrics */}
      <section className="py-20 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-foreground mb-12 text-center">Impact Metrics (2026)</h2>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="p-8 text-center border-t-4 border-t-primary">
              <div className="text-4xl font-bold text-primary mb-2">40,000</div>
              <p className="text-foreground/70 font-medium">Qur'ans Distributed</p>
            </Card>
            <Card className="p-8 text-center border-t-4 border-t-accent">
              <div className="text-4xl font-bold text-accent mb-2">10,000+</div>
              <p className="text-foreground/70 font-medium">Orphans & Underserved Learners Prioritized</p>
            </Card>
            <Card className="p-8 text-center border-t-4 border-t-primary">
              <div className="text-4xl font-bold text-primary mb-2">1,000+</div>
              <p className="text-foreground/70 font-medium">Institutions Reached</p>
            </Card>
            <Card className="p-8 text-center border-t-4 border-t-accent">
              <div className="text-4xl font-bold text-accent mb-2">6+</div>
              <p className="text-foreground/70 font-medium">Currencies Accepted</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Global Sponsorship */}
      <section className="py-20 px-4 bg-secondary/30">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-foreground mb-12 text-center">Global Sponsorship Pathways</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: 'Single Copy Sponsor',
                price: '350 BDT / $3.25 / £2.75',
                description: 'Sponsor one memorization-optimized Qur\'an for a deserving student'
              },
              {
                title: 'Batch Sponsor',
                price: '242,920 BDT / $2,200 / £1,800',
                description: '1,000 copies — Institutional distribution with recognition'
              },
              {
                title: 'Debt Recovery Partner',
                price: 'Custom Amount',
                description: 'Support legacy dues and institutional healing'
              },
              {
                title: 'Infrastructure Patron',
                price: 'Custom Amount',
                description: 'Sponsor team rebuilding, technology, and logistics'
              },
              {
                title: 'Global Campaign Ally',
                price: 'Custom Amount',
                description: 'Fund outreach, media production, and donor engagement'
              },
              {
                title: 'Legacy Partner',
                price: 'Lifetime Recognition',
                description: 'Perpetual honor in our records and annual impact reports'
              }
            ].map((sponsor, index) => (
              <Card key={index} className="p-6">
                <h3 className="text-lg font-semibold text-primary mb-2">{sponsor.title}</h3>
                <p className="text-sm font-medium text-accent mb-3">{sponsor.price}</p>
                <p className="text-foreground/70 text-sm">{sponsor.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Transparency */}
      <section className="py-20 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-foreground mb-12 text-center">Transparency & Accountability</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 flex items-start gap-4">
              <Award className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-foreground mb-2">Monthly Reports</h3>
                <p className="text-foreground/70 text-sm">
                  Budget dashboards in BDT, USD, GBP with real-time progress tracking
                </p>
              </div>
            </Card>
            
            <Card className="p-8 flex items-start gap-4">
              <Target className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-foreground mb-2">Distribution Registry</h3>
                <p className="text-foreground/70 text-sm">
                  Recipient signatures, photo documentation, and GPS-tagged logs
                </p>
              </div>
            </Card>
          </div>

          <Card className="mt-8 p-8 bg-primary/5 border-2 border-primary/20">
            <h3 className="text-lg font-semibold text-foreground mb-4">Complete Transparency</h3>
            <ul className="space-y-2 text-foreground/70 text-sm">
              <li>✓ Post-campaign impact report with audit summary</li>
              <li>✓ Donor portal with live currency conversion</li>
              <li>✓ Automated receipt generation and verification</li>
              <li>✓ External audit compliance via UK registration</li>
              <li>✓ Changelog documentation of all transactions</li>
            </ul>
          </Card>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Stand With Us</h2>
          <p className="text-xl text-primary-foreground/90 mb-8">
            Quraner Fariwala now stands at a crossroads: revival or retreat. With your help, 
            we will not only print Qur'ans—we will restore dignity, rebuild legacy, and illuminate generations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-accent text-foreground hover:bg-accent/90">
              <Link href="/donate">Sponsor Now</Link>
            </Button>
            <Button asChild size="lg" variant="outline" 
              className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 bg-transparent">
              <Link href="/contact">Get More Info</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
