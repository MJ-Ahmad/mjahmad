'use client'

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { Download, FileText, CheckCircle, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function SponsorshipTracker() {
  // Sample data for demonstration
  const monthlyProgress = [
    { month: 'Jan', target: 2000, collected: 1800 },
    { month: 'Feb', target: 2500, collected: 2400 },
    { month: 'Mar', target: 3000, collected: 2800 },
    { month: 'Apr', target: 3500, collected: 3200 },
  ]

  const currencyBreakdown = [
    { name: 'USD', value: 45000 },
    { name: 'GBP', value: 35000 },
    { name: 'BDT', value: 28000000 },
    { name: 'EUR', value: 12000 },
  ]

  const sponsorshipTiers = [
    { name: 'Single Copy (350 BDT)', count: 450, color: '#8b9d4a' },
    { name: 'Batch (1000 copies)', count: 12, color: '#ffd700' },
    { name: 'Debt Recovery', count: 5, color: '#4a9d6b' },
    { name: 'Infrastructure', count: 3, color: '#6b9d4a' },
  ]

  const recentDonations = [
    { id: 'D001', donor: 'Ahmed Khan', amount: '$3.25', type: 'Single Copy', date: '2025-01-15', status: 'Verified' },
    { id: 'D002', donor: 'Fatima Ali', amount: '£2,200', type: 'Batch Sponsor', date: '2025-01-14', status: 'Verified' },
    { id: 'D003', donor: 'Anonymous', amount: '15,000 BDT', type: 'Monthly', date: '2025-01-13', status: 'Processing' },
    { id: 'D004', donor: 'Omar Hassan', amount: '$22,500', type: 'Debt Partner', date: '2025-01-12', status: 'Verified' },
    { id: 'D005', donor: 'Zainab Ahmed', amount: '$11,000', type: 'Campaign Ally', date: '2025-01-11', status: 'Verified' },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Page Header */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-5xl font-bold text-foreground mb-4">Sponsorship Tracker</h1>
          <p className="text-xl text-foreground/70 max-w-2xl">
            Real-time, auditor-ready tracking of all campaign contributions, impact metrics, and distribution progress.
          </p>
        </div>
      </section>

      {/* KPI Cards */}
      <section className="py-12 px-4 bg-secondary/20">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="p-6 border-l-4 border-l-primary">
              <p className="text-sm text-foreground/70 mb-2">Total Collected</p>
              <div className="text-3xl font-bold text-primary mb-1">$145,500</div>
              <p className="text-xs text-foreground/60">99.3% of target</p>
            </Card>
            <Card className="p-6 border-l-4 border-l-accent">
              <p className="text-sm text-foreground/70 mb-2">Total Sponsors</p>
              <div className="text-3xl font-bold text-accent mb-1">470</div>
              <p className="text-xs text-foreground/60">+15% this month</p>
            </Card>
            <Card className="p-6 border-l-4 border-l-primary">
              <p className="text-sm text-foreground/70 mb-2">Qur'ans Printed</p>
              <div className="text-3xl font-bold text-primary mb-1">38,500</div>
              <p className="text-xs text-foreground/60">96% complete</p>
            </Card>
            <Card className="p-6 border-l-4 border-l-accent">
              <p className="text-sm text-foreground/70 mb-2">Distributed</p>
              <div className="text-3xl font-bold text-accent mb-1">32,200</div>
              <p className="text-xs text-foreground/60">83% delivered</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Charts Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 mb-8">
            {/* Monthly Progress */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-6">Monthly Collection Progress</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyProgress}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" stroke="var(--foreground)" />
                  <YAxis stroke="var(--foreground)" />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'var(--card)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px'
                    }}
                    cursor={{ fill: 'var(--primary)', opacity: 0.1 }}
                  />
                  <Legend />
                  <Bar dataKey="target" fill="var(--muted-foreground)" name="Target" />
                  <Bar dataKey="collected" fill="var(--primary)" name="Collected" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Sponsorship Distribution */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-6">Sponsorship Tier Distribution</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={sponsorshipTiers}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, count }) => `${name}: ${count}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="count"
                  >
                    {sponsorshipTiers.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'var(--card)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Currency Breakdown */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">Currency Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={currencyBreakdown}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" stroke="var(--foreground)" />
                <YAxis stroke="var(--foreground)" />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'var(--card)',
                    border: '1px solid var(--border)',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="var(--primary)" 
                  strokeWidth={2}
                  name="Amount"
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>
      </section>

      {/* Recent Donations Table */}
      <section className="py-20 px-4 bg-secondary/20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-8">Recent Donations</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-primary">
                  <th className="text-left py-4 px-4 text-foreground font-semibold">Transaction ID</th>
                  <th className="text-left py-4 px-4 text-foreground font-semibold">Donor</th>
                  <th className="text-right py-4 px-4 text-foreground font-semibold">Amount</th>
                  <th className="text-left py-4 px-4 text-foreground font-semibold">Type</th>
                  <th className="text-left py-4 px-4 text-foreground font-semibold">Date</th>
                  <th className="text-center py-4 px-4 text-foreground font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {recentDonations.map((donation) => (
                  <tr key={donation.id} className="hover:bg-primary/5 transition-colors">
                    <td className="py-4 px-4 font-mono text-xs text-primary">{donation.id}</td>
                    <td className="py-4 px-4 text-foreground">{donation.donor}</td>
                    <td className="text-right py-4 px-4 text-foreground font-semibold">{donation.amount}</td>
                    <td className="py-4 px-4 text-foreground/70">{donation.type}</td>
                    <td className="py-4 px-4 text-foreground/70">{donation.date}</td>
                    <td className="py-4 px-4 text-center">
                      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${
                        donation.status === 'Verified' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {donation.status === 'Verified' ? (
                          <>
                            <CheckCircle className="w-3 h-3" />
                            {donation.status}
                          </>
                        ) : (
                          <>
                            <Clock className="w-3 h-3" />
                            {donation.status}
                          </>
                        )}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Audit Reports */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Auditor-Ready Reports</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-6 flex flex-col">
              <FileText className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Monthly Summary</h3>
              <p className="text-foreground/70 mb-6 flex-1">
                Complete financial summary with all transactions categorized and verified
              </p>
              <Button asChild variant="outline" className="w-full bg-transparent">
                <a href="#download">Download PDF</a>
              </Button>
            </Card>

            <Card className="p-6 flex flex-col">
              <Download className="w-12 h-12 text-accent mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Distribution Registry</h3>
              <p className="text-foreground/70 mb-6 flex-1">
                Complete recipient list with signatures, photos, and GPS coordinates
              </p>
              <Button asChild variant="outline" className="w-full bg-transparent">
                <a href="#download">Download Excel</a>
              </Button>
            </Card>

            <Card className="p-6 flex flex-col">
              <FileText className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Impact Report</h3>
              <p className="text-foreground/70 mb-6 flex-1">
                Comprehensive impact analysis with testimonials and verification data
              </p>
              <Button asChild variant="outline" className="w-full bg-transparent">
                <a href="#download">Download Report</a>
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Compliance Section */}
      <section className="py-20 px-4 bg-primary/5">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-8">Compliance & Verification</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8">
              <h3 className="text-lg font-semibold text-foreground mb-4">UK Registration</h3>
              <ul className="space-y-2 text-foreground/70 text-sm">
                <li>✓ Registered Charity: Reg. 14066998</li>
                <li>✓ SIC Code: 85600 (Educational Support)</li>
                <li>✓ TRAD License: DSCC/03727/2021</li>
                <li>✓ Full audit trail maintained</li>
              </ul>
            </Card>

            <Card className="p-8">
              <h3 className="text-lg font-semibold text-foreground mb-4">Data Security</h3>
              <ul className="space-y-2 text-foreground/70 text-sm">
                <li>✓ End-to-end encryption for donor data</li>
                <li>✓ IPFS content integrity verification</li>
                <li>✓ Automated backup and archival</li>
                <li>✓ GDPR compliant data handling</li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
