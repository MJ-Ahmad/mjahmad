import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { ChevronRight } from 'lucide-react'

const galleryItems = [
  {
    id: 1,
    title: 'Handwritten Manuscript',
    category: 'Research',
    description: 'Historical Quranic manuscripts from our collection',
    color: 'from-purple-500 to-pink-500',
  },
  {
    id: 2,
    title: 'Printing Process',
    category: 'Production',
    description: 'Modern printing techniques ensuring quality',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 3,
    title: 'Community Distribution',
    category: 'Distribution',
    description: 'Qurans being distributed to communities',
    color: 'from-green-500 to-emerald-500',
  },
  {
    id: 4,
    title: 'Research Library',
    category: 'Research',
    description: 'Extensive collection of scholarly works',
    color: 'from-orange-500 to-red-500',
  },
  {
    id: 5,
    title: 'Quality Control',
    category: 'Production',
    description: 'Rigorous quality assurance processes',
    color: 'from-indigo-500 to-purple-500',
  },
  {
    id: 6,
    title: 'International Outreach',
    category: 'Distribution',
    description: 'Global partnerships and distribution networks',
    color: 'from-yellow-500 to-orange-500',
  },
]

export default function GalleryPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-4">Our Gallery</h1>
          <p className="text-lg text-foreground/70 max-w-2xl">
            Explore the journey of the Holy Quran through our research, printing, and distribution
            efforts across the globe.
          </p>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-20 px-4 flex-1">
        <div className="max-w-7xl mx-auto">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {galleryItems.map((item) => (
              <div
                key={item.id}
                className="group cursor-pointer overflow-hidden rounded-lg border border-border hover:border-primary/30 transition-all"
              >
                {/* Image Placeholder with Gradient */}
                <div
                  className={`w-full h-48 bg-gradient-to-br ${item.color} opacity-90 group-hover:opacity-100 transition-opacity flex items-center justify-center`}
                >
                  <div className="text-center text-white">
                    <div className="text-4xl mb-2">📸</div>
                    <p className="text-sm opacity-75">Gallery Image</p>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 bg-background">
                  <div className="mb-2">
                    <span className="inline-block px-3 py-1 bg-accent/10 text-accent text-xs font-medium rounded-full">
                      {item.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-foreground/70 text-sm">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-secondary/30">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">Learn About Our Work</h2>
          <p className="text-foreground/70 mb-8">
            Discover more about our research, production, and distribution processes.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild variant="default" className="bg-primary text-primary-foreground">
              <Link href="/production">
                View Production Process
                <ChevronRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
            <Button asChild variant="outline" className="border-primary text-primary bg-transparent">
              <Link href="/distribution">Distribution Network</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
