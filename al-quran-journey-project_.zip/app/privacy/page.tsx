import { Header } from '@/components/header'
import { Footer } from '@/components/footer'

export default function PrivacyPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Hero */}
      <section className="py-12 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-foreground mb-2">Privacy Policy</h1>
          <p className="text-foreground/70">Last updated: January 2025</p>
        </div>
      </section>

      {/* Content */}
      <section className="flex-1 py-16 px-4">
        <div className="max-w-4xl mx-auto prose prose-invert">
          <div className="space-y-8">
            {[
              {
                title: '1. Introduction',
                content:
                  'AlQuranJourney ("we," "us," or "our") operates the AlQuranJourney website and donation platform (the "Service"). This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website.',
              },
              {
                title: '2. Information We Collect',
                content:
                  'We collect information you provide directly, including your name, email address, phone number, mailing address, and payment information when you make a donation. We also collect information automatically through cookies and analytics tools, including your IP address, browser type, and pages visited.',
              },
              {
                title: '3. How We Use Your Information',
                content:
                  'We use your information to process donations, send receipts and tax documentation, communicate about our mission, send newsletter updates (if you opt-in), improve our website and services, and comply with legal obligations.',
              },
              {
                title: '4. Data Security',
                content:
                  'We implement industry-standard security measures including SSL encryption to protect your personal and payment information. However, no method of transmission over the Internet is 100% secure, and we cannot guarantee absolute security.',
              },
              {
                title: '5. Your Rights',
                content:
                  'You have the right to access, update, or delete your personal information. You can opt-out of marketing communications at any time by clicking the unsubscribe link in our emails. To exercise these rights, please contact us through our contact page.',
              },
              {
                title: '6. Cookies and Analytics',
                content:
                  'We use cookies to enhance your experience on our website. These cookies help us understand how you use our site and allow you to return without re-entering information. You can control cookie settings through your browser.',
              },
              {
                title: '7. Third-Party Services',
                content:
                  'Our website may contain links to third-party websites. We are not responsible for the privacy practices of these external sites. We encourage you to review their privacy policies before providing any personal information.',
              },
              {
                title: '8. Payment Processing',
                content:
                  'Payment information is processed through secure payment gateways that comply with PCI DSS standards. We do not store credit card information on our servers after transaction completion.',
              },
              {
                title: '9. Children\'s Privacy',
                content:
                  'Our Service is not directed to children under the age of 13. We do not knowingly collect personal information from children under 13. If we become aware that we have collected such information, we will take steps to delete it.',
              },
              {
                title: '10. Changes to This Policy',
                content:
                  'We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new policy on our website and updating the "Last updated" date. Your continued use of the Service constitutes acceptance of changes.',
              },
              {
                title: '11. Contact Us',
                content:
                  'If you have questions about this Privacy Policy or our privacy practices, please contact us through our Contact page or email. We will respond to your inquiry within 30 days.',
              },
              {
                title: '12. Data Retention',
                content:
                  'We retain your personal information for as long as necessary to fulfill the purposes for which it was collected, including to satisfy legal, accounting, or reporting requirements. You can request deletion of your data at any time.',
              },
            ].map((section, index) => (
              <div key={index}>
                <h2 className="text-2xl font-bold text-foreground mb-4">{section.title}</h2>
                <p className="text-foreground/70 leading-relaxed">{section.content}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
