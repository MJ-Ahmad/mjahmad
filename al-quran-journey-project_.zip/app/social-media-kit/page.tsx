'use client'

import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Copy, Download, Share2 } from 'lucide-react'
import { useState } from 'react'

export default function SocialMediaKit() {
  const [copiedText, setCopiedText] = useState('')

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopiedText(id)
    setTimeout(() => setCopiedText(''), 2000)
  }

  const taglines = [
    'From Bangladesh to the Ummah: A Qur\'an in Every Hand',
    'Sponsor Healing, Heritage, and Hifz',
    'Rebuild the Legacy. Illuminate the Future.',
    '40,000 Qur\'ans. Infinite Impact.',
    'Restore Dignity. Rebuild Legacy. Illuminate Generations.',
    'Heritage • Scholarship • Unity'
  ]

  const hashtagSets = [
    {
      name: 'Campaign Hashtags',
      tags: '#Ramadhan2026 #QuranerFariwala #HolyQuran #MemorizationOptimized #Quranic #Heritage'
    },
    {
      name: 'Global Reach',
      tags: '#PreserveTheQuran #SpiritualLegacy #FaithInAction #CharitableCause #DonateNow'
    },
    {
      name: 'Impact Focused',
      tags: '#QuranicAccess #OrphanSupport #IslamicEducation #HifzCentre #SpreadTheWord'
    },
    {
      name: 'Community',
      tags: '#Bangladesh #MuslimCommunity #UmmahUnited #EduJustice #SocialGood'
    }
  ]

  const socialPosts = [
    {
      platform: 'Facebook/LinkedIn',
      text: '📜 Imagine a classroom bathed in morning sunlight, where young voices rise in soulful recitation.\n\nQuraner Fariwala is printing 40,000 memorization-optimized Qur\'ans by January 2026—prioritizing orphans and underserved Hifz centres across Bangladesh and South Asia.\n\nJoin us: From Bangladesh to the Ummah, a Qur\'an in every hand.\n\n🤝 Sponsor today → [link]\n\n#Ramadhan2026 #QuranerFariwala #HolyQuran'
    },
    {
      platform: 'Twitter/X',
      text: '🕌 Heritage • Scholarship • Unity\n\n40,000 Qur\'ans. Infinite impact.\n\nSponsor a memorization-optimized Qur\'an for a deserving student in Bangladesh. Every contribution honors a legacy.\n\n💚 Join the revival:\n[link]\n\n#Ramadhan2026 #FaithInAction'
    },
    {
      platform: 'Instagram Caption',
      text: 'From Bangladesh to the Ummah 🌍\n\nWe\'re on a mission to print and distribute 40,000 memorization-optimized Qur\'ans by Ramadhan 2026.\n\nEvery page becomes a beacon of hope for orphans and underserved learners.\n\n✨ Heritage • Scholarship • Unity ✨\n\nSponsor today—link in bio\n\n#QuranerFariwala #HolyQuran #MemorizationOptimized #IslamicEducation #SpreadTheWord'
    },
    {
      platform: 'TikTok/YouTube Shorts',
      text: '[Video 15-30 seconds]\n\nNarration: "40,000 Qur\'ans. One noble mission. Meet Quraner Fariwala."\n\nShow: Student reciting Qur\'an → Printing process → Distribution to classrooms → Child\'s smile\n\nEnd text: "Sponsor a Qur\'an. Change a life. Link in bio."\n\nMusic: Inspirational Islamic instrumental'
    }
  ]

  const colorPalette = [
    { name: 'Primary Green', hex: '#7B7D4A', rgb: 'RGB(123, 125, 74)' },
    { name: 'Accent Gold', hex: '#FFE4A1', rgb: 'RGB(255, 228, 161)' },
    { name: 'Dark Foreground', hex: '#0A0F0F', rgb: 'RGB(10, 15, 15)' },
    { name: 'Light Background', hex: '#F8F9F8', rgb: 'RGB(248, 249, 248)' },
    { name: 'Neutral Gray', hex: '#D9D9D9', rgb: 'RGB(217, 217, 217)' },
  ]

  const designGuidelines = [
    {
      category: 'Logo Usage',
      guidelines: [
        'Use "ق" (Qaf) Arabic letter in primary green with white text',
        'Always include tagline: "Research • Printing • Distribution"',
        'Maintain 1:1 aspect ratio for circular logo',
        'Never distort or rotate the logo'
      ]
    },
    {
      category: 'Typography',
      guidelines: [
        'Headings: Bold, sans-serif for maximum impact',
        'Body: Clear, readable sans-serif (minimum 14pt on social)',
        'Arabic text: High-contrast, well-spaced',
        'Always pair English with Arabic or Bangla translations'
      ]
    },
    {
      category: 'Imagery',
      guidelines: [
        'Authentic shots: Students reciting, printing process, distribution',
        'Avoid stock photos—use real testimonials and moments',
        'Include diverse, representative imagery of South Asian students',
        'Always respect privacy—blur faces if donors wish'
      ]
    },
    {
      category: 'Tone & Voice',
      guidelines: [
        'Respectful, dignified, faith-centered',
        'Transparent about impact, costs, and distribution',
        'Inclusive: Welcome all donors regardless of faith',
        'Action-oriented: Clear CTAs in every post'
      ]
    }
  ]

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      {/* Page Header */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-5xl font-bold text-foreground mb-4">Social Media Kit</h1>
          <p className="text-xl text-foreground/70 max-w-2xl">
            Branded assets, messaging, and guidelines for amplifying the Ramadhan-2026 campaign across all platforms.
          </p>
        </div>
      </section>

      {/* Brand Taglines */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Campaign Taglines</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {taglines.map((tagline, index) => (
              <Card key={index} className="p-6 flex items-center justify-between group hover:border-primary/50 transition-all">
                <p className="text-foreground font-medium">{tagline}</p>
                <button
                  onClick={() => copyToClipboard(tagline, `tagline-${index}`)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                  title="Copy to clipboard"
                >
                  <Copy className={`w-5 h-5 ${copiedText === `tagline-${index}` ? 'text-green-500' : 'text-primary'}`} />
                </button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Hashtag Sets */}
      <section className="py-20 px-4 bg-secondary/20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Hashtag Sets</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {hashtagSets.map((set, index) => (
              <Card key={index} className="p-6">
                <h3 className="font-semibold text-foreground mb-4">{set.name}</h3>
                <div className="bg-secondary p-4 rounded-lg mb-4 font-mono text-sm text-foreground/70 break-words">
                  {set.tags}
                </div>
                <button
                  onClick={() => copyToClipboard(set.tags, `hashtags-${index}`)}
                  className="flex items-center gap-2 text-primary hover:text-accent transition-colors text-sm"
                >
                  <Copy className="w-4 h-4" />
                  {copiedText === `hashtags-${index}` ? 'Copied!' : 'Copy Hashtags'}
                </button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Social Posts */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Ready-to-Use Posts</h2>
          <div className="space-y-6">
            {socialPosts.map((post, index) => (
              <Card key={index} className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-lg text-foreground">{post.platform}</h3>
                  <button
                    onClick={() => copyToClipboard(post.text, `post-${index}`)}
                    className="flex items-center gap-2 text-primary hover:text-accent transition-colors text-sm"
                  >
                    <Copy className="w-4 h-4" />
                    {copiedText === `post-${index}` ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                <div className="bg-secondary p-4 rounded-lg whitespace-pre-wrap text-sm text-foreground/70 font-mono overflow-x-auto">
                  {post.text}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Color Palette */}
      <section className="py-20 px-4 bg-secondary/20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Color Palette</h2>
          <div className="grid md:grid-cols-5 gap-6">
            {colorPalette.map((color, index) => (
              <Card key={index} className="overflow-hidden">
                <div
                  className="h-32 w-full"
                  style={{ backgroundColor: color.hex }}
                />
                <div className="p-4">
                  <h3 className="font-semibold text-foreground text-sm mb-2">{color.name}</h3>
                  <p className="text-xs text-foreground/70 font-mono mb-3">{color.hex}</p>
                  <p className="text-xs text-foreground/60 font-mono mb-3">{color.rgb}</p>
                  <button
                    onClick={() => copyToClipboard(color.hex, `color-${index}`)}
                    className="text-xs text-primary hover:text-accent transition-colors w-full py-1"
                  >
                    {copiedText === `color-${index}` ? 'Copied!' : 'Copy Hex'}
                  </button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Design Guidelines */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-foreground mb-12">Design Guidelines</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {designGuidelines.map((guideline, index) => (
              <Card key={index} className="p-6">
                <h3 className="text-lg font-semibold text-primary mb-6">{guideline.category}</h3>
                <ul className="space-y-3">
                  {guideline.guidelines.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex gap-3 text-foreground/70 text-sm">
                      <span className="text-primary font-bold flex-shrink-0">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Help Amplify Our Message</h2>
          <p className="text-xl text-primary-foreground/90 mb-8">
            Share these assets and messages on your social media platforms to reach more donors 
            and supporters of the Ramadhan-2026 campaign.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-accent text-foreground hover:bg-accent/90">
              <a href="#download" className="flex items-center gap-2">
                <Download className="w-4 h-4" />
                Download Full Kit
              </a>
            </Button>
            <Button asChild size="lg" variant="outline"
              className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 bg-transparent">
              <a href="/donate" className="flex items-center gap-2">
                <Share2 className="w-4 h-4" />
                Share Campaign
              </a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
